# DeepEval Runbook Prompt Package

This package gives you a **simple one-shot way** to create a usable prompt from a folder of runbooks.

## What it does
- Reads all `.md` and `.txt` files from a runbooks folder
- Extracts runbook titles and summaries
- Builds:
  - `output/generated_prompt.txt`
  - `output/generated_prompt.json`
- Uses **one PowerShell command** to set everything up and run

## Simple execution

Open PowerShell in this folder and run:

```powershell
./setup_and_run.ps1
```

It will:
1. Create a virtual environment
2. Install dependencies
3. Read files from `example_runbooks`
4. Generate the prompt in the `output` folder

## Use your own runbooks
Replace the files inside `example_runbooks` with your own `.md` or `.txt` runbooks, then run:

```powershell
./setup_and_run.ps1
```

## Optional custom folder
You can point to a different folder:

```powershell
./setup_and_run.ps1 -RunbooksPath "C:\my-runbooks"
```

## Output files
- `output/generated_prompt.txt`
- `output/generated_prompt.json`

## Notes
- This package is intentionally simple.
- It generates a strong **execution-planner prompt** from your runbooks.
- It does **not** do full prompt optimization by itself. DeepEval supports prompt optimization and synthetic dataset generation, but that needs eval cases and a model setup. DeepEval documents prompt optimization with `PromptOptimizer`, `GEPA`, and `MIPROV2`, and synthetic goldens generation via `Synthesizer`. citeturn0search4turn0search8turn0search16
