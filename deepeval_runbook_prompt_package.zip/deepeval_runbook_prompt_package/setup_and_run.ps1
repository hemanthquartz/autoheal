param(
    [string]$RunbooksPath = ".\example_runbooks"
)

$ErrorActionPreference = "Stop"

Write-Host "Creating virtual environment..."
if (-not (Test-Path ".\.venv")) {
    python -m venv .venv
}

Write-Host "Activating virtual environment..."
& .\.venv\Scripts\Activate.ps1

Write-Host "Upgrading pip..."
python -m pip install --upgrade pip

Write-Host "Installing requirements..."
pip install -r .\requirements.txt

Write-Host "Generating prompt from runbooks..."
python .\generate_prompt.py --runbooks $RunbooksPath --output .\output

Write-Host ""
Write-Host "Done."
Write-Host "Generated files:"
Write-Host " - .\output\generated_prompt.txt"
Write-Host " - .\output\generated_prompt.json"
