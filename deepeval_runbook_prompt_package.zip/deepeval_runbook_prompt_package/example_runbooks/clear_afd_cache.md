# Clear Azure Front Door Cache

Purpose:
Clear cached content from an Azure Front Door endpoint.

Execution:
- Validate subscription
- Validate resource group, profile, endpoint
- Purge the required paths
- Print status

CLI:
az afd endpoint purge --resource-group <rg> --profile-name <profile> --endpoint-name <endpoint> --content-paths "/*"
