# Read Azure App Service Properties

Purpose:
Read and print details of an Azure App Service.

Execution:
- Validate subscription
- Print web app details
- Print config
- Print app settings

CLI:
az webapp show --resource-group <rg> --name <app_name>
az webapp config show --resource-group <rg> --name <app_name>
az webapp config appsettings list --resource-group <rg> --name <app_name>
