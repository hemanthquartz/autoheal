import argparse
import json
import re
from pathlib import Path

def clean_text(text: str) -> str:
    text = text.replace("\r", "")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def summarize(text: str, max_len: int = 350) -> str:
    text = clean_text(text)
    lines = [ln.strip("-* ").strip() for ln in text.splitlines() if ln.strip()]
    merged = " ".join(lines[:10])
    merged = re.sub(r"\s+", " ", merged).strip()
    if len(merged) > max_len:
        merged = merged[: max_len - 3].rstrip() + "..."
    return merged

def extract_title(path: Path, text: str) -> str:
    for line in text.splitlines():
        if line.strip().startswith("#"):
            return re.sub(r"^#+\s*", "", line.strip())
    return path.stem.replace("_", " ").replace("-", " ").title()

def load_runbooks(runbooks_path: Path):
    runbooks = []
    for path in sorted(runbooks_path.rglob("*")):
        if path.is_file() and path.suffix.lower() in {".md", ".txt"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
            title = extract_title(path, text)
            summary = summarize(text)
            runbooks.append({
                "id": path.stem,
                "title": title,
                "summary": summary,
                "path": str(path)
            })
    return runbooks

def build_prompt(runbooks):
    runbook_block = []
    for rb in runbooks:
        runbook_block.append(
            f'- id: "{rb["id"]}"\n'
            f'  title: "{rb["title"]}"\n'
            f'  summary: "{rb["summary"]}"'
        )

    runbooks_text = "\n".join(runbook_block)

    prompt = f"""You are a runbook execution planner.

You will receive:
1. A user request
2. A list of available runbooks

Your job:
- Understand the user's real operational intent first.
- Select the single best runbook, or the smallest possible combination of runbooks, needed to complete the task.
- Convert the chosen runbook content into practical execution steps.
- Prefer Azure CLI or PowerShell when the task is operational.
- Do not invent resource names, IDs, subscriptions, URLs, secrets, or values that are not given.
- If a value is missing, clearly mark it as a placeholder.
- Keep the output action-oriented and execution-ready.
- Do not write long explanations.
- Return valid JSON only.

Available runbooks:
{runbooks_text}

Required JSON format:
{{
  "selected_runbooks": ["runbook_id"],
  "goal": "short description of the intended task",
  "assumptions": ["only if truly needed"],
  "execution_steps": [
    {{
      "step": 1,
      "action": "what to do",
      "command": "exact Azure CLI or PowerShell command if applicable",
      "expected_result": "what should happen"
    }}
  ]
}}

Decision rules:
- Choose the runbook whose goal and execution pattern best match the request.
- If multiple runbooks overlap, prefer the one with the most direct operational fit.
- If the request asks to inspect, print, list, show, read, or fetch properties, return read-only steps.
- If the request asks to clear, purge, restart, rotate, update, disable, or enable, return action steps with safe ordering.
- Add a validation/check step before a destructive step whenever possible.
- Keep the commands minimal and realistic.

Now wait for the user request and respond with JSON only."""
    return prompt.strip()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--runbooks", required=True, help="Folder containing .md or .txt runbooks")
    parser.add_argument("--output", default="output", help="Output folder")
    args = parser.parse_args()

    runbooks_path = Path(args.runbooks)
    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    if not runbooks_path.exists():
        raise SystemExit(f"Runbooks folder not found: {runbooks_path}")

    runbooks = load_runbooks(runbooks_path)
    if not runbooks:
        raise SystemExit("No .md or .txt runbooks found.")

    prompt = build_prompt(runbooks)

    txt_file = output_path / "generated_prompt.txt"
    json_file = output_path / "generated_prompt.json"

    txt_file.write_text(prompt, encoding="utf-8")
    json_file.write_text(json.dumps({
        "runbook_count": len(runbooks),
        "runbooks": runbooks,
        "prompt": prompt
    }, indent=2), encoding="utf-8")

    print(f"Runbooks loaded: {len(runbooks)}")
    print(f"Prompt file: {txt_file.resolve()}")
    print(f"JSON file: {json_file.resolve()}")

if __name__ == "__main__":
    main()
