Azure Front Door Cache Purge

Symptom
Users continue receiving stale content through Azure Front Door Standard/Premium, or a deployment has completed and cached content must be invalidated immediately.

Purpose
This runbook provides a safe, repeatable workflow to:
- validate the cache purge request
- confirm the exact Front Door profile, endpoint, domain, and path scope
- purge only the intended content
- verify that fresh content is now being served

⚠️ Strict execution order is mandatory. No steps may be skipped.

Resolution A — Intake / Safety Gate 🔐 (Mandatory Entry Point)
When to Use
Always. This resolution must be completed before any purge action.

Inputs
- Subscription ID or active Azure subscription context
- Resource group name
- Azure Front Door profile name
- Endpoint name
- Domain(s) to purge
- Content path(s) to purge
- Change ticket / incident reference
- Confirmation that purge scope is approved

Steps
1. Review the request payload or incident details.
2. Confirm the purge is for Azure Front Door Standard or Premium.
3. Confirm the requested paths are correct.
4. Confirm whether the purge should target:
   - a single file, or
   - a folder path, or
   - the full domain using /*
5. Confirm the intended business impact and maintenance window if broad invalidation is requested.

Decision Logic

If any required input is missing:
🔴 STOP
Do not run any purge command
Escalate for clarification

If purge scope is broad (for example /* on production domain) and approval is not recorded:
🔴 STOP
Do not purge
Escalate for approval

If inputs and approval are complete:
✅ Proceed to Resolution B

🔒 Hard Gate
No purge action is permitted unless the target scope is fully validated.

Resolution B — Confirm Target Object 🧭
When to Use
After Resolution A succeeds and before attempting cache purge.

Validation Checklist
- Resource group exists
- Profile exists
- Endpoint exists
- Domain belongs to the endpoint/profile
- Paths are correctly formatted

Suggested CLI Checks
```bash
az account show -o table

az afd profile show \
  --resource-group <resource-group> \
  --profile-name <profile-name> \
  -o json

az afd endpoint show \
  --resource-group <resource-group> \
  --profile-name <profile-name> \
  --endpoint-name <endpoint-name> \
  -o json
```

Outcome

If profile or endpoint is not found:
🔴 STOP
Do not purge
Escalate for manual investigation

If validation succeeds:
✅ Proceed to Resolution C

Resolution C — Purge Cache 🧹
When to Use
Only after Resolution B confirms the exact target.

Execution
Run the purge against the validated endpoint, domains, and content paths.

Suggested CLI
```bash
az afd endpoint purge \
  --resource-group <resource-group> \
  --profile-name <profile-name> \
  --endpoint-name <endpoint-name> \
  --domains <domain1> <domain2> \
  --content-paths '/path/file.js' '/images/*'
```

Examples
Single file:
```bash
az afd endpoint purge \
  --resource-group rg-prod-network \
  --profile-name afd-prod-global \
  --endpoint-name app-prod-endpoint \
  --domains app.contoso.com \
  --content-paths '/static/app.js'
```

Full site/domain purge:
```bash
az afd endpoint purge \
  --resource-group rg-prod-network \
  --profile-name afd-prod-global \
  --endpoint-name app-prod-endpoint \
  --domains app.contoso.com \
  --content-paths '/*'
```

Failure Handling

If CLI returns authorization or resource errors:
🔴 STOP
Capture the error output
Escalate for manual investigation

If purge command succeeds:
✅ Proceed to Resolution D

Resolution D — Verify Fresh Content ✅ (Mandatory)
When to Use
Immediately after a successful purge.

Steps
1. Request the affected URL(s) through the Front Door endpoint or custom domain.
2. Confirm the returned content reflects the latest deployment/content version.
3. Validate with application owner, deployment pipeline output, checksum, version marker, or timestamp if available.
4. Repeat validation from at least one additional client or region if the incident is high severity.

Validation Results

Fresh content is confirmed:
✅ Close the incident / update the change record

Fresh content is not confirmed:
🔴 STOP
Do not repeat broad purges blindly
Escalate for deeper cache, origin, or deployment investigation

Completion Criteria
The request may be closed only when:
- purge request was approved
- target profile/endpoint/domain/path were validated
- purge command completed successfully
- fresh content was confirmed after purge

References
- Azure Front Door cache purge using Azure CLI
- Azure CLI az afd endpoint commands
- Azure Front Door purge REST API
