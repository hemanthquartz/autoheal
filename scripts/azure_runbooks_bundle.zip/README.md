Azure Cloud Operational Runbooks

Files included
1. azure_front_door_clear_cache.md
2. azure_app_service_read_properties.md
3. azure_multiple_webapps_read_properties.md
4. azure_vm_read_properties.md
5. azure_storage_accounts_read_properties.md
6. azure_monitor_metrics_multiple_resources.md

Design notes
- These runbooks follow the same operational style as the examples you shared:
  - symptom
  - purpose
  - mandatory safety gates
  - strict execution order
  - resolution blocks
  - decision logic
  - completion criteria
- The runbooks are written in markdown so you can edit them easily and commit them into your repository.
- Commands are intentionally read-only except for the Front Door cache purge runbook, which includes explicit approval and verification gates.

Recommended next additions
- restart Azure App Service safely
- restart Azure VM only after health checks
- clear Azure CDN endpoint cache
- rotate Key Vault secret version with validation
- scale Azure Container App / App Service plan with rollback gate
- print Azure Front Door route / origin / rule-set properties
- Cosmos DB account health / throughput inspection
