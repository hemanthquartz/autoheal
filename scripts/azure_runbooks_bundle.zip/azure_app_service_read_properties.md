Azure App Service — Read and Print Properties

Symptom
An operator needs to inspect the configuration or runtime properties of an Azure App Service or Web App for troubleshooting, audit, migration, or validation.

Purpose
This runbook provides a safe workflow to:
- identify the exact App Service instance
- read configuration and metadata without changing state
- print the most important properties for review
- capture output for incident or audit evidence

⚠️ Strict execution order is mandatory. No modification commands are allowed in this runbook.

Resolution A — Safety Gate 🔐 (Mandatory First Step)
When to Use
Always.

Inputs
- Subscription / tenant context
- Resource group
- Web App name
- Incident or change reference
- Reason for inspection

Steps
1. Confirm the request is read-only.
2. Confirm the exact app name and resource group.
3. Confirm the operator is using the intended subscription.

Decision Logic

If the operator cannot identify the exact target:
🔴 STOP
Do not query random resources
Escalate for clarification

If target details are complete:
✅ Proceed to Resolution B

Resolution B — Confirm Resource 🧭
When to Use
After Resolution A.

Suggested CLI
```bash
az account show -o table

az webapp show \
  --resource-group <resource-group> \
  --name <webapp-name> \
  -o json
```

Expected Review Points
- id
- name
- location
- state
- hostNames
- reserved (Linux vs Windows)
- serverFarmId
- httpsOnly
- enabled
- clientAffinityEnabled

Outcome

Resource not found:
🔴 STOP
Escalate for manual investigation

Resource confirmed:
✅ Proceed to Resolution C

Resolution C — Read and Print Core Properties 📄
When to Use
After confirming the app exists.

Suggested CLI
```bash
az webapp show \
  --resource-group <resource-group> \
  --name <webapp-name> \
  --query "{name:name,state:state,location:location,defaultHostName:defaultHostName,httpsOnly:httpsOnly,enabled:enabled,kind:kind,serverFarmId:serverFarmId}" \
  -o json
```

Optional: print app settings names only
```bash
az webapp config appsettings list \
  --resource-group <resource-group> \
  --name <webapp-name> \
  --query "[].name" \
  -o table
```

Optional: print site config
```bash
az webapp config show \
  --resource-group <resource-group> \
  --name <webapp-name> \
  -o json
```

If secrets or connection strings are requested:
🔴 STOP
Do not print sensitive values into shared channels unless explicitly authorized

If required properties were successfully captured:
✅ Proceed to Resolution D

Resolution D — Store Output and Close ✅
When to Use
After all required properties are collected.

Steps
1. Save command output to the incident or change record.
2. Confirm no mutation commands were executed.
3. Share only the minimum necessary fields with stakeholders.

Completion Criteria
This runbook is complete only when:
- the correct app was identified
- properties were collected in read-only mode
- sensitive values were not exposed improperly
- the evidence was attached to the incident/change

References
- Azure CLI az webapp commands
- Azure CLI az resource commands
