Azure Monitor — Read and Print Metrics for Multiple Resources

Symptom
Operations needs to compare health or usage metrics across multiple Azure resources during an incident, post-change validation, or capacity review.

Purpose
This runbook provides a safe workflow to:
- validate the target resources
- identify the correct metric namespace and metric names
- query metrics in read-only mode
- print results for investigation

⚠️ Strict execution order is mandatory. This runbook does not change resource state.

Resolution A — Intake / Safety Gate 🔐
Inputs
- Subscription
- Resource IDs or resource names
- Resource type(s)
- Metric name(s)
- Time window
- Aggregation type
- Incident / change reference

Steps
1. Confirm the target resources.
2. Confirm the requested time window.
3. Confirm the exact metric names.
4. Confirm whether each resource uses the same metric namespace.

If any required input is missing:
🔴 STOP
Escalate for clarification

If inputs are complete:
✅ Proceed to Resolution B

Resolution B — Confirm Metrics Availability 🧭
Suggested Guidance
Check supported metrics by resource type before querying production incidents at scale.

Suggested CLI
```bash
az monitor metrics list \
  --resource <resource-id> \
  --metric "Requests" \
  --interval PT5M \
  --aggregation Total \
  -o json
```

If metric name or namespace is invalid:
🔴 STOP
Correct the metric selection before proceeding

If metrics are available:
✅ Proceed to Resolution C

Resolution C — Query and Print Metrics 📈
Single resource example
```bash
az monitor metrics list \
  --resource <resource-id> \
  --metric "Requests" \
  --interval PT5M \
  --aggregation Total \
  --start-time <start-time> \
  --end-time <end-time> \
  -o json
```

Multiple resource example
```bash
for id in <resource-id-1> <resource-id-2> <resource-id-3>
do
  az monitor metrics list \
    --resource "$id" \
    --metric "Requests" \
    --interval PT5M \
    --aggregation Total \
    --start-time <start-time> \
    --end-time <end-time> \
    -o json
done
```

Recommended Review
- timestamp
- total / average / minimum / maximum
- missing datapoints
- consistency across resources

If one or more queries fail:
🔴 STOP
Record failed resource IDs and errors
Escalate for manual review

If outputs are collected:
✅ Proceed to Resolution D

Resolution D — Validate and Close ✅
Steps
1. Confirm all requested resources were queried.
2. Confirm the time window and aggregation match the request.
3. Attach the output to the incident/change record.

Completion Criteria
Close only when:
- the requested resources and metrics were validated
- queries ran in read-only mode
- outputs were captured and shared safely

References
- Azure Monitor metrics overview
- Azure CLI az monitor metrics list
- Supported metrics by resource type
