Azure Virtual Machine — Read and Print Properties

Symptom
An operator needs current VM details such as provisioning state, power state, size, location, or tags without changing the VM.

Purpose
This runbook provides a safe workflow to:
- identify the exact VM
- collect core properties
- inspect runtime state using instance view
- capture results for troubleshooting or audit

⚠️ Strict execution order is mandatory. This runbook is read-only.

Resolution A — Safety Gate 🔐
When to Use
Always.

Inputs
- Subscription
- Resource group
- VM name
- Incident / change reference

Steps
1. Confirm the VM name and resource group.
2. Confirm the action is read-only.
3. Confirm the correct subscription context.

If details are incomplete:
🔴 STOP
Escalate for clarification

If details are complete:
✅ Proceed to Resolution B

Resolution B — Confirm VM Exists 🧭
Suggested CLI
```bash
az vm show \
  --resource-group <resource-group> \
  --name <vm-name> \
  -o json
```

If VM is not found:
🔴 STOP
Escalate for manual investigation

If VM is found:
✅ Proceed to Resolution C

Resolution C — Read and Print Core / Runtime Properties 📄
Suggested CLI for resource properties
```bash
az vm show \
  --resource-group <resource-group> \
  --name <vm-name> \
  --query "{name:name,location:location,vmSize:hardwareProfile.vmSize,provisioningState:provisioningState,osType:storageProfile.osDisk.osType,tags:tags}" \
  -o json
```

Suggested CLI for instance view / power state
```bash
az vm get-instance-view \
  --resource-group <resource-group> \
  --name <vm-name> \
  -o json
```

Suggested focused query
```bash
az vm get-instance-view \
  --resource-group <resource-group> \
  --name <vm-name> \
  --query "{name:name,statuses:instanceView.statuses}" \
  -o json
```

Interpretation Guidance
- provisioningState shows deployment/provisioning result
- power state is obtained from instance view statuses

If command output is incomplete or unauthorized:
🔴 STOP
Record the error
Escalate for access or resource review

If required data is collected:
✅ Proceed to Resolution D

Resolution D — Record and Close ✅
Steps
1. Attach VM property output to the incident/change.
2. Highlight the current power state and provisioning state.
3. Confirm no changes were made to the VM.

Completion Criteria
The task is complete only when:
- the correct VM was identified
- core and runtime properties were collected
- outputs were recorded
- no mutation action was performed

References
- Azure CLI az vm commands
- Azure VM states and billing status
- VM Instance View REST API
