Azure Storage Accounts — Read and Print Properties for Multiple Services

Symptom
An operator needs inventory and property details for multiple Azure Storage Accounts across one or more resource groups.

Purpose
This runbook provides a safe workflow to:
- validate the list of storage accounts
- read configuration details in read-only mode
- print consistent properties for comparison or audit

⚠️ Strict execution order is mandatory. No storage account updates are permitted in this runbook.

Resolution A — Intake / Validation 🔐
Required Inputs
- Subscription
- List of storage account names
- Resource group(s), if known
- Requested fields
- Incident / change reference

Steps
1. Validate the list of storage account names.
2. Remove duplicates.
3. Confirm required output fields.

If the list is ambiguous:
🔴 STOP
Escalate for clarification

If the list is valid:
✅ Proceed to Resolution B

Resolution B — Discover / Confirm Accounts 🧭
Suggested CLI
```bash
az storage account list \
  --query "[].{name:name,resourceGroup:resourceGroup,location:primaryLocation,sku:sku.name,kind:kind}" \
  -o table
```

Targeted confirmation
```bash
az storage account show \
  --resource-group <resource-group> \
  --name <storage-account-name> \
  -o json
```

If any account is not found:
🔴 STOP
Document the missing account
Escalate for follow-up

If all targets are confirmed:
✅ Proceed to Resolution C

Resolution C — Print Selected Properties 📋
Suggested CLI
```bash
az storage account show \
  --resource-group <resource-group> \
  --name <storage-account-name> \
  --query "{name:name,location:primaryLocation,sku:sku.name,kind:kind,accessTier:accessTier,allowBlobPublicAccess:allowBlobPublicAccess,minimumTlsVersion:minimumTlsVersion,publicNetworkAccess:publicNetworkAccess}" \
  -o json
```

Multi-account example
```bash
for acct in stapp01 stapp02 stapp03
do
  az storage account show \
    --resource-group <resource-group> \
    --name "$acct" \
    --query "{name:name,location:primaryLocation,sku:sku.name,kind:kind,accessTier:accessTier,minimumTlsVersion:minimumTlsVersion}" \
    -o json
done
```

If output includes sensitive data requests:
🔴 STOP
Do not expose keys or secrets through this runbook

If required properties are collected:
✅ Proceed to Resolution D

Resolution D — Review and Close ✅
Steps
1. Validate the output against the requested storage accounts.
2. Save the results to the incident/change record.
3. Confirm that no key or secret material was printed.

Completion Criteria
The task is complete only when:
- all requested accounts were validated
- selected properties were printed consistently
- sensitive values were not exposed
- results were stored for audit / troubleshooting
