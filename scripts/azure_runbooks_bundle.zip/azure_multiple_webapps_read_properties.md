Azure App Services — Read and Print Properties for Multiple Services

Symptom
Operations or engineering needs a consolidated view of multiple Azure App Services for troubleshooting, migration, compliance, or comparison.

Purpose
This runbook provides a repeatable workflow to:
- validate a list of services
- inspect each service in read-only mode
- print selected properties in a consistent format
- produce a combined output for review

⚠️ Strict execution order is mandatory. No write operations are allowed.

Resolution A — Intake / Validation 🔐
When to Use
Always.

Required Inputs
- Subscription
- Resource group(s)
- List of Web App names
- Output fields required by the requester
- Incident/change reference

Steps
1. Validate the app list.
2. Remove duplicates.
3. Confirm whether all apps are in the same resource group.
4. Confirm the output format required: table, json, or csv-like text.

Decision Logic

If the service list is incomplete or ambiguous:
🔴 STOP
Escalate for clarification

If the list is valid:
✅ Proceed to Resolution B

Resolution B — Confirm Each Service Exists 🧭
When to Use
Before bulk property collection.

Suggested CLI
```bash
for app in app1 app2 app3
do
  az webapp show \
    --resource-group <resource-group> \
    --name "$app" \
    --query "{name:name,state:state,defaultHostName:defaultHostName,location:location,httpsOnly:httpsOnly}" \
    -o json
done
```

Alternative for mixed resource groups
```bash
az resource list \
  --resource-type Microsoft.Web/sites \
  --query "[].{name:name,resourceGroup:resourceGroup,location:location,id:id}" \
  -o table
```

If one or more apps are missing:
🔴 STOP
Do not assume replacements
Report which apps were not found

If all target services are found:
✅ Proceed to Resolution C

Resolution C — Print Consolidated Properties 📋
When to Use
After resource validation.

Suggested CLI
```bash
for app in app1 app2 app3
do
  az webapp show \
    --resource-group <resource-group> \
    --name "$app" \
    --query "{name:name,state:state,location:location,defaultHostName:defaultHostName,httpsOnly:httpsOnly,enabled:enabled,kind:kind}" \
    -o json
done
```

Optional output shaping with TSV
```bash
for app in app1 app2 app3
do
  az webapp show \
    --resource-group <resource-group> \
    --name "$app" \
    --query "[name,state,location,defaultHostName,httpsOnly]" \
    -o tsv
done
```

Optional capture to file
```bash
for app in app1 app2 app3
do
  az webapp show \
    --resource-group <resource-group> \
    --name "$app" \
    --query "{name:name,state:state,location:location,defaultHostName:defaultHostName,httpsOnly:httpsOnly}" \
    -o json >> webapps_properties.json
done
```

If a command fails on any app:
🔴 STOP
Record the failed app and error
Escalate for manual follow-up

If all outputs are collected:
✅ Proceed to Resolution D

Resolution D — Review and Close ✅
Steps
1. Verify that the printed properties match the requested services.
2. Confirm no sensitive fields were exposed.
3. Attach the consolidated output to the incident/change record.

Completion Criteria
The task is complete only when:
- all requested apps were validated
- properties were captured consistently
- failures, if any, were explicitly documented
- outputs were stored for audit or troubleshooting

References
- Azure CLI az webapp commands
- Azure CLI az resource list
