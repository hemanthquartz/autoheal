from fastapi import FastAPI
from pydantic import BaseModel
import uuid

app = FastAPI()

# In-memory store (later → DB / Redis)
PENDING_APPROVALS = {}

class ApprovalRequest(BaseModel):
    alert: dict
    runbook: str
    confidence: float
    content: str

@app.post("/request-approval")
def request_approval(req: ApprovalRequest):
    approval_id = str(uuid.uuid4())

    PENDING_APPROVALS[approval_id] = {
        "status": "PENDING",
        "data": req
    }

    print("\n📨 APPROVAL REQUEST CREATED")
    print(f"Approval ID: {approval_id}")
    print(f"Runbook: {req.runbook}")
    print(f"Confidence: {req.confidence}%")

    return {
        "approval_id": approval_id,
        "status": "PENDING",
        "message": "Waiting for human approval"
    }

@app.post("/approve/{approval_id}")
def approve(approval_id: str):
    if approval_id not in PENDING_APPROVALS:
        return {"error": "Invalid approval ID"}

    PENDING_APPROVALS[approval_id]["status"] = "APPROVED"

    print(f"\n✅ APPROVAL GRANTED: {approval_id}")

    return {
        "approval_id": approval_id,
        "status": "APPROVED"
    }

@app.post("/reject/{approval_id}")
def reject(approval_id: str):
    if approval_id not in PENDING_APPROVALS:
        return {"error": "Invalid approval ID"}

    PENDING_APPROVALS[approval_id]["status"] = "REJECTED"

    print(f"\n❌ APPROVAL REJECTED: {approval_id}")

    return {
        "approval_id": approval_id,
        "status": "REJECTED"
    }
