import os
from dotenv import load_dotenv
load_dotenv()

from pinecone import Pinecone
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

# ---------------- CONFIG ----------------
RUNBOOK_DIR = "./runbooks"
INDEX_NAME = os.getenv("PINECONE_INDEX")

# ---------------- INIT ------------------
pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
index = pc.Index(INDEX_NAME)

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key=os.getenv("OPENAI_API_KEY")
)

# ---------------- LOGIC -----------------
def load_runbooks():
    runbooks = []
    for file in os.listdir(RUNBOOK_DIR):
        if file.endswith(".md"):
            path = os.path.join(RUNBOOK_DIR, file)
            with open(path, "r", encoding="utf-8") as f:
                runbooks.append((file, f.read()))
    return runbooks

def index_runbooks():
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=100
    )

    vectors = []

    for filename, content in load_runbooks():
        chunks = splitter.split_text(content)

        for i, chunk in enumerate(chunks):
            embedding = embeddings.embed_query(chunk)

            vectors.append({
                "id": f"{filename}-{i}",
                "values": embedding,
                "metadata": {
                    "runbook": filename,
                    "content": chunk
                }
            })

    index.upsert(vectors=vectors)
    print(f"✅ Indexed {len(vectors)} runbook chunks into Pinecone")

# ---------------- RUN -------------------
if __name__ == "__main__":
    index_runbooks()
