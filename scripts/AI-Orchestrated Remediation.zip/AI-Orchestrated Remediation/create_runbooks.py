import os

BASE_DIR = "runbooks"

runbooks = {
    "db_proxy_restart.md": """# Database Proxy Restart

Description:
This runbook is used when backend services fail to connect to the database.

Symptoms:
- connection timeout
- database unreachable
- slow queries
- pool exhaustion
- errors while connecting to Postgres or MySQL

Root Cause:
Database proxy becomes unresponsive due to idle, leaked, or excessive connections.

Fix:
Restart the database proxy to clear stale connections and reset the pool.

Automation:
GitHub Action: db-proxy-remediation.yml

Required Inputs:
- service
- region
- database_host
""",

    "service_restart.md": """# Service Restart

Description:
Use this runbook when an application service becomes unresponsive.

Symptoms:
- HTTP 503 / 504 errors
- service not responding
- request timeout
- degraded performance

Root Cause:
Service process is stuck, deadlocked, or in an unhealthy state.

Fix:
Restart the affected service to restore normal operation.

Automation:
GitHub Action: service-restart.yml

Required Inputs:
- service
- region
- environment
""",

    "disk_cleanup.md": """# Disk Cleanup

Description:
This runbook handles disk space exhaustion issues.

Symptoms:
- no space left on device
- disk usage exceeds threshold
- application unable to write logs
- inode exhaustion

Root Cause:
Excessive log files, temporary files, or unrotated data.

Fix:
Clean temporary files and rotate old logs.

Automation:
GitHub Action: disk-cleanup.yml

Required Inputs:
- host
- filesystem
- region
""",

    "high_cpu_throttling.md": """# High CPU Throttling

Description:
Use when CPU usage remains high for prolonged periods.

Symptoms:
- CPU usage above 90%
- throttling alerts
- slow response times

Root Cause:
Traffic spikes, inefficient code, or runaway processes.

Fix:
Throttle traffic or restart the service to release CPU pressure.

Automation:
GitHub Action: cpu-throttle.yml

Required Inputs:
- service
- region
- pod_name
""",

    "memory_leak_restart.md": """# Memory Leak Restart

Description:
Handles issues related to excessive memory consumption.

Symptoms:
- out of memory errors
- memory usage continuously increasing
- pod killed due to OOM

Root Cause:
Memory leak in application or dependency.

Fix:
Restart the service to free allocated memory.

Automation:
GitHub Action: memory-restart.yml

Required Inputs:
- service
- region
- pod_name
""",

    "pod_crashloop.md": """# Pod CrashLoopBackOff Recovery

Description:
Use when Kubernetes pods enter CrashLoopBackOff state.

Symptoms:
- pod repeatedly restarting
- crash loop detected
- deployment unstable

Root Cause:
Bad configuration, missing environment variables, or startup failure.

Fix:
Restart pod and validate configuration.

Automation:
GitHub Action: pod-restart.yml

Required Inputs:
- namespace
- pod_name
- cluster
""",

    "cache_flush.md": """# Cache Flush

Description:
Use when cached data causes stale or incorrect responses.

Symptoms:
- outdated data
- incorrect responses
- cache inconsistency

Root Cause:
Stale cache entries or corrupted cache state.

Fix:
Flush cache to force fresh data retrieval.

Automation:
GitHub Action: cache-flush.yml

Required Inputs:
- service
- region
- cache_type
""",

    "auth_service_issue.md": """# Authentication Service Issue

Description:
Handles failures in authentication or authorization services.

Symptoms:
- login failures
- authentication timeout
- invalid token errors
- 401 / 403 responses

Root Cause:
Auth service downtime or token validation failure.

Fix:
Restart authentication service and verify token configuration.

Automation:
GitHub Action: auth-service-restart.yml

Required Inputs:
- service
- region
- auth_provider
""",

    "network_latency.md": """# Network Latency Mitigation

Description:
Use when network latency increases unexpectedly.

Symptoms:
- high latency alerts
- slow inter-service communication
- packet loss

Root Cause:
Network congestion or routing issues.

Fix:
Reroute traffic or restart affected network components.

Automation:
GitHub Action: network-mitigation.yml

Required Inputs:
- region
- service
- destination
""",

    "deployment_rollback.md": """# Deployment Rollback

Description:
Use when a recent deployment causes instability.

Symptoms:
- error rate spike after deployment
- service degradation
- rollback alerts

Root Cause:
Faulty release or incompatible configuration.

Fix:
Rollback to the last known stable deployment.

Automation:
GitHub Action: rollback-deployment.yml

Required Inputs:
- service
- region
- deployment_version
"""
}

# Create directory
os.makedirs(BASE_DIR, exist_ok=True)

# Create files
for filename, content in runbooks.items():
    path = os.path.join(BASE_DIR, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

print("✅ Runbooks directory and files created successfully!")
