import os
import json
import requests
from dotenv import load_dotenv
load_dotenv()

from pinecone import Pinecone
from langchain_openai import OpenAIEmbeddings

# ---------------- CONFIG ----------------
INDEX_NAME = os.getenv("PINECONE_INDEX")
ALERT_FILE = "alert.json"
APPROVAL_API = "http://localhost:8000/request-approval"

# ---------------- INIT ------------------
pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
index = pc.Index(INDEX_NAME)

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-small",
    api_key=os.getenv("OPENAI_API_KEY")
)

# ---------------- LOGIC -----------------
def load_alert():
    with open(ALERT_FILE, "r") as f:
        return json.load(f)

def find_runbook(alert_text):
    query_embedding = embeddings.embed_query(alert_text)

    response = index.query(
        vector=query_embedding,
        top_k=3,
        include_metadata=True
    )

    return response["matches"]

# ---------------- RUN -------------------
if __name__ == "__main__":
    alert = load_alert()
    alert_text = alert["log"]

    print("\n🚨 ALERT RECEIVED")
    print(alert_text)

    matches = find_runbook(alert_text)

    best = matches[0]

    print("\n✅ TOP RUNBOOK MATCH")
    print(f"Score: {round(best['score'] * 100, 2)}%")
    print(f"Runbook: {best['metadata']['runbook']}")
    print("\n📘 Matched Content:")
    print(best["metadata"]["content"])

    # ---------------- APPROVAL PAYLOAD ----------------
    payload = {
        "alert": alert,
        "runbook": best["metadata"]["runbook"],
        "confidence": round(best["score"] * 100, 2),
        "content": best["metadata"]["content"]
    }

    resp = requests.post(APPROVAL_API, json=payload)
