🧠 AI-Orchestrated Remediation with Human-in-the-Loop (HITL)

This project implements an AI-assisted incident remediation system that:

Reads alerts

Finds the most relevant runbook using AI semantic search

Sends an approval request

Waits for human approval before proceeding

This README documents what each file does, when to run it, and exact commands — up to the API server & approval system.

📁 Current Project Structure
AI Remidation/
├── __pycache__/                 # Python cache (ignore)
├── venv/                        # Python virtual environment
├── runbooks/                    # All remediation runbooks (.md files)
│
├── .env                         # Environment variables (API keys)
├── alert.json                   # Sample alert input
│
├── approval_service.py          # Approval API server (HITL)
├── create_runbooks.py           # Helper to create runbooks (optional)
├── index_runbooks.py            # Index runbooks into Pinecone (ONE-TIME)
├── search_runbook.py            # Alert → Runbook → Approval request
│
├── requirements.txt             # Python dependencies

🔐 Environment Configuration (.env)

Purpose:
Stores all sensitive configuration securely.

.env (example)
OPENAI_API_KEY=sk-xxxxxxxxxxxx
PINECONE_API_KEY=xxxxxxxx-xxxx
PINECONE_INDEX=runbooks-index






📦 Install & Setup
1️⃣ Create virtual environment (ONE TIME)
python -m venv venv
venv\Scripts\activate    # Windows

2️⃣ Install dependencies
pip install -r requirements.txt

📘 Runbooks (runbooks/)

Purpose:
Markdown files that describe how to fix incidents.

Used by AI for semantic search

No code changes required when adding new runbooks

You can manually add/edit .md files here

🧠 Index Runbooks (ONE-TIME STEP)
File: index_runbooks.py

Purpose:

Reads all runbooks

Generates embeddings using OpenAI

Stores them in Pinecone (persistent)

When to run:

First-time setup

Whenever runbooks change

Command:
python index_runbooks.py


✅ Output example:

Indexed 25 runbook chunks into Pinecone


⚠️ Do NOT run this for every alert.

🚨 Alert Input (alert.json)

Purpose:
Simulates an alert (from Splunk / monitoring tools).

Example:
{
  "log": "CRITICAL: payment-service unable to connect to database. Connection timeout observed.",
  "severity": "critical",
  "service": "payment-service",
  "region": "us-east-1"
}


You can edit this file to test different scenarios.

🔍 Search Runbook & Request Approval
File: search_runbook.py

Purpose:

Reads alert.json

Finds the most relevant runbook using Pinecone + OpenAI

Sends an approval request to the API server

When to run:

For every incoming alert

Command:
python search_runbook.py

What happens:

Alert is read

AI finds best runbook

Confidence score calculated

Approval request is sent

🧑‍⚖️ Approval API Server (HITL)
File: approval_service.py

Purpose:

Receives approval requests

Generates approval IDs

Tracks approval state (PENDING / APPROVED / REJECTED)

(Optional) Sends Outlook approval email

Start the server (MUST be running)
uvicorn approval_service:app --port 8000


Server URL:

http://localhost:8000

✅ Full Execution Order (IMPORTANT)
1️⃣ Activate environment
venv\Scripts\activate

2️⃣ Start approval server
uvicorn approval_service:app --port 8000

3️⃣ (One time) Index runbooks
python index_runbooks.py

4️⃣ Trigger alert processing
python search_runbook.py


➡️ Approval request is now created
➡️ Human approval is required to proceed

🧪 Manual Approval (Temporary – Local Testing)
Approve (PowerShell)
Invoke-RestMethod -Method POST http://localhost:8000/approve/<approval_id>

Reject
Invoke-RestMethod -Method POST http://localhost:8000/reject/<approval_id>


In production, this is replaced by Outlook email approval buttons

🧩 File Responsibilities (Quick Reference)
File	Purpose
create_runbooks.py	Helper to generate runbook files
index_runbooks.py	Embed & store runbooks in Pinecone
search_runbook.py	Alert → AI → Approval request
approval_service.py	Human approval API
alert.json	Test alert input
runbooks/	All remediation knowledge
.env	Secrets & configuration
requirements.txt	Dependencies
✅ What Is Completed

✔ AI-based runbook matching
✔ Fast Pinecone vector search
✔ Secure .env configuration
✔ Human-in-the-loop approval API
✔ Enterprise-ready architecture

⏭️ Next Steps (Future Work)

Trigger GitHub Actions after approval

Store approvals in database

Outlook Adaptive Card integration

Authentication & audit logging

Deploy API server to cloud