# High CPU Throttling

Description:
Use when CPU usage remains high for prolonged periods.

Symptoms:
- CPU usage above 90%
- throttling alerts
- slow response times

Root Cause:
Traffic spikes, inefficient code, or runaway processes.

Fix:
Throttle traffic or restart the service to release CPU pressure.

Automation:
GitHub Action: cpu-throttle.yml

Required Inputs:
- service
- region
- pod_name
