# Disk Cleanup

Description:
This runbook handles disk space exhaustion issues.

Symptoms:
- no space left on device
- disk usage exceeds threshold
- application unable to write logs
- inode exhaustion

Root Cause:
Excessive log files, temporary files, or unrotated data.

Fix:
Clean temporary files and rotate old logs.

Automation:
GitHub Action: disk-cleanup.yml

Required Inputs:
- host
- filesystem
- region
