# Database Proxy Restart

Description:
This runbook is used when backend services fail to connect to the database.

Symptoms:
- connection timeout
- database unreachable
- slow queries
- pool exhaustion
- errors while connecting to Postgres or MySQL

Root Cause:
Database proxy becomes unresponsive due to idle, leaked, or excessive connections.

Fix:
Restart the database proxy to clear stale connections and reset the pool.

Automation:
GitHub Action: db-proxy-remediation.yml

Required Inputs:
- service
- region
- database_host
