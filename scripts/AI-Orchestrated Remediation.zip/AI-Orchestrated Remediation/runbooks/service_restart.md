# Service Restart

Description:
Use this runbook when an application service becomes unresponsive.

Symptoms:
- HTTP 503 / 504 errors
- service not responding
- request timeout
- degraded performance

Root Cause:
Service process is stuck, deadlocked, or in an unhealthy state.

Fix:
Restart the affected service to restore normal operation.

Automation:
GitHub Action: service-restart.yml

Required Inputs:
- service
- region
- environment
