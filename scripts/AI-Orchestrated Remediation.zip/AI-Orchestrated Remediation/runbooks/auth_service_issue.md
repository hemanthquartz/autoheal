# Authentication Service Issue

Description:
Handles failures in authentication or authorization services.

Symptoms:
- login failures
- authentication timeout
- invalid token errors
- 401 / 403 responses

Root Cause:
Auth service downtime or token validation failure.

Fix:
Restart authentication service and verify token configuration.

Automation:
GitHub Action: auth-service-restart.yml

Required Inputs:
- service
- region
- auth_provider
