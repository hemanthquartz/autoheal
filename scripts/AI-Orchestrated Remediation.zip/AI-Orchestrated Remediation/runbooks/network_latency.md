# Network Latency Mitigation

Description:
Use when network latency increases unexpectedly.

Symptoms:
- high latency alerts
- slow inter-service communication
- packet loss

Root Cause:
Network congestion or routing issues.

Fix:
Reroute traffic or restart affected network components.

Automation:
GitHub Action: network-mitigation.yml

Required Inputs:
- region
- service
- destination
