# Cache Flush

Description:
Use when cached data causes stale or incorrect responses.

Symptoms:
- outdated data
- incorrect responses
- cache inconsistency

Root Cause:
Stale cache entries or corrupted cache state.

Fix:
Flush cache to force fresh data retrieval.

Automation:
GitHub Action: cache-flush.yml

Required Inputs:
- service
- region
- cache_type
