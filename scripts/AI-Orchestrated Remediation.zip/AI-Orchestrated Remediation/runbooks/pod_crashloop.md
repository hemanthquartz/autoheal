# Pod CrashLoopBackOff Recovery

Description:
Use when Kubernetes pods enter CrashLoopBackOff state.

Symptoms:
- pod repeatedly restarting
- crash loop detected
- deployment unstable

Root Cause:
Bad configuration, missing environment variables, or startup failure.

Fix:
Restart pod and validate configuration.

Automation:
GitHub Action: pod-restart.yml

Required Inputs:
- namespace
- pod_name
- cluster
