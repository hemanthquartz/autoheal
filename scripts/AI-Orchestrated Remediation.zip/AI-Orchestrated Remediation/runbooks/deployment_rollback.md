# Deployment Rollback

Description:
Use when a recent deployment causes instability.

Symptoms:
- error rate spike after deployment
- service degradation
- rollback alerts

Root Cause:
Faulty release or incompatible configuration.

Fix:
Rollback to the last known stable deployment.

Automation:
GitHub Action: rollback-deployment.yml

Required Inputs:
- service
- region
- deployment_version
