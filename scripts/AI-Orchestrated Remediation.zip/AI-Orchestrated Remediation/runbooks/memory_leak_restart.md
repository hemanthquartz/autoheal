# Memory Leak Restart

Description:
Handles issues related to excessive memory consumption.

Symptoms:
- out of memory errors
- memory usage continuously increasing
- pod killed due to OOM

Root Cause:
Memory leak in application or dependency.

Fix:
Restart the service to free allocated memory.

Automation:
GitHub Action: memory-restart.yml

Required Inputs:
- service
- region
- pod_name
