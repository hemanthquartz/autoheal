$ErrorActionPreference = 'Stop'
$env:AWS_PAGER = ''

Set-Location "C:\Users\Keerthi\OneDrive\Documents\cft"
$region = 'us-east-1'

function Get-StackOutput([string]$stackName, [string]$key) {
    $q = "Stacks[0].Outputs[?OutputKey=='$key'].OutputValue | [0]"
    $val = aws cloudformation describe-stacks --stack-name $stackName --region $region --query $q --output text
    if (-not $val -or $val -eq 'None') { throw "Missing output $key from $stackName" }
    return $val.Trim()
}

$queueUrl = Get-StackOutput 'emr-eks-cf-orchestration' 'OrchestrationQueueUrl'
$stateMachineArn = Get-StackOutput 'emr-eks-cf-orchestration' 'StateMachineArn'
$tableName = Get-StackOutput 'emr-eks-cf-orchestration' 'JobStateTableName'

$workflowId = "wf-sales-insurance-" + (Get-Date -Format 'yyyyMMddHHmmss')

# Job config (code location, pod config, Spark params) lives in the DynamoDB job-catalog table.
# The SQS payload only carries the workflow structure: job names + dependencies.
$payload = [ordered]@{
    workflowId = $workflowId
    jobs = @(
        @{ name = 'sales-ingest';              dependsOn = @() },
        @{ name = 'insurance-ingest';          dependsOn = @() },
        @{ name = 'customer-reference-build';  dependsOn = @() },

        @{ name = 'sales-curation';            dependsOn = @('sales-ingest','customer-reference-build') },
        @{ name = 'insurance-claims-curation'; dependsOn = @('insurance-ingest','customer-reference-build') },

        @{ name = 'customer-360-join';         dependsOn = @('sales-curation','insurance-claims-curation') },
        @{ name = 'risk-scoring';              dependsOn = @('insurance-claims-curation','customer-360-join') },
        @{ name = 'sales-forecast';            dependsOn = @('sales-curation','customer-360-join') },

        @{ name = 'fraud-detection';           dependsOn = @('risk-scoring','insurance-claims-curation') },
        @{ name = 'executive-kpi-publish';     dependsOn = @('sales-forecast','fraud-detection') }
    )
}

$body = $payload | ConvertTo-Json -Depth 10 -Compress
$payloadPath = "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\workflow-sales-insurance-payload.json"
[System.IO.File]::WriteAllText($payloadPath, $body, [System.Text.Encoding]::ASCII)

$send = aws sqs send-message --region $region --queue-url $queueUrl --message-body "file://$payloadPath" --output json | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) { throw 'Failed to send SQS message' }

$result = [pscustomobject]@{
    workflowId      = $workflowId
    messageId       = $send.MessageId
    queueUrl        = $queueUrl
    stateMachineArn = $stateMachineArn
    tableName       = $tableName
    payloadPath     = $payloadPath
    jobCount        = $payload.jobs.Count
}

$result | ConvertTo-Json -Compress | Set-Content "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\last-workflow-sales-insurance.json" -Encoding ASCII
$result | ConvertTo-Json -Depth 5
