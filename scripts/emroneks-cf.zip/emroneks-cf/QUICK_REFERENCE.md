# CloudFormation Templates - Quick Reference

## Files in This Directory

1. **1-network-stack.yaml** - VPC, Subnets, Security Groups
2. **2-iam-stack.yaml** - IAM Roles, Policies, S3 Bucket  
3. **3-eks-cluster-stack.yaml** - EKS Cluster, Node Groups, Auto Scaling
4. **4-emr-virtual-clusters-stack.yaml** - EMR Virtual Clusters, Spark Operator
5. **5-storage-stack.yaml** - Storage Classes, S3, Spark History Server
6. **6-monitoring-stack.yaml** - CloudWatch, Prometheus, Grafana, Fluent-Bit
7. **deploy-all.ps1** - Automated deployment script (PowerShell)
8. **DEPLOYMENT_GUIDE.md** - Detailed deployment instructions
9. **README.md** - Architecture overview and features

## Quick Deploy Commands

### Option 1: Automated (Recommended)

```powershell
# Run the complete deployment
.\deploy-all.ps1 -Region us-east-1 -ClusterName emr-eks-karpenter

# With custom parameters
.\deploy-all.ps1 `
  -Region us-east-1 `
  -ClusterName my-cluster `
  -NodeDesiredSize 3 `
  -NodeMinSize 2 `
  -NodeMaxSize 10 `
  -NodeInstanceType t3.2xlarge
```

### Option 2: Manual Deployment

```bash
# Stack 1: Network
aws cloudformation create-stack \
  --stack-name emr-eks-cf-network \
  --template-body file://1-network-stack.yaml \
  --region us-east-1

# Wait for completion
aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-network --region us-east-1

# Stack 2: IAM
aws cloudformation create-stack \
  --stack-name emr-eks-cf-iam \
  --template-body file://2-iam-stack.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1

# ... continue with remaining stacks
```

## Deployment Flow

```
┌─────────────────────┐
│  1. Network Stack   │  ← Foundation
└──────────┬──────────┘
           │
  ┌────────┴────────┐
  │                 │
  ▼                 ▼
┌──────────┐  ┌──────────┐
│ IAM      │  │ 2. IAM   │  
│ Roles    │  │ Stack    │  ← Identity & Auth
└──────────┘  └──────────┘
              │
              ▼
        ┌──────────────┐
        │ 3. EKS       │
        │ Cluster      │  ← Kubernetes Orchestration
        │ Stack        │
        └──────┬───────┘
               │
    ┌──────────┼──────────┐
    │          │          │
    ▼          ▼          ▼
┌─────┐  ┌─────────┐  ┌──────────┐
│ 4.  │  │ 5.      │  │ 6.       │
│ EMR │  │ Storage │  │Monitoring│
│     │  │         │  │          │
└─────┘  └─────────┘  └──────────┘
   ↓          ↓            ↓
Complete → Complete → Complete
```

## Key Parameters

### Network Stack (1-network-stack.yaml)

| Parameter | Default | Description |
|-----------|---------|-------------|
| VpcCIDR | 10.1.0.0/16 | Main VPC network |
| SecondaryVpcCIDR | 100.64.0.0/16 | Data plane network |
| PublicSubnet1CIDR | 10.1.1.0/24 | Public subnet AZ1 |
| PublicSubnet2CIDR | 10.1.2.0/24 | Public subnet AZ2 |
| PrivateSubnet1CIDR | 10.1.11.0/24 | Private subnet AZ1 |
| PrivateSubnet2CIDR | 10.1.12.0/24 | Private subnet AZ2 |
| DataSubnet1CIDR | 100.64.11.0/24 | Data subnet AZ1 |
| DataSubnet2CIDR | 100.64.12.0/24 | Data subnet AZ2 |

### EKS Cluster Stack (3-eks-cluster-stack.yaml)

| Parameter | Default | Description |
|-----------|---------|-------------|
| ClusterName | emr-eks-karpenter | EKS cluster name |
| KubernetesVersion | 1.34 | Kubernetes version |
| NodeDesiredSize | 2 | Desired number of nodes |
| NodeMinSize | 1 | Minimum nodes for ASG |
| NodeMaxSize | 3 | Maximum nodes for ASG |
| NodeInstanceType | m5.xlarge | EC2 instance type |
| BlockDeviceSize | 100 | Root volume size (GB) |

## Common Tasks

### Get Cluster Info

```bash
# Get cluster endpoint
aws eks describe-cluster --name emr-eks-karpenter \
  --region us-east-1 \
  --query 'cluster.endpoint' \
  --output text

# Get node IP addresses
kubectl get nodes -o wide

# Check cluster health
kubectl get componentstatuses
```

### Scale Cluster

```bash
# Update desired capacity
aws autoscaling set-desired-capacity \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg \
  --desired-capacity 5 \
  --region us-east-1

# Check current capacity
aws autoscaling describe-auto-scaling-groups \
  --auto-scaling-group-names emr-eks-karpenter-core-node-asg \
  --query 'AutoScalingGroups[0].{Min:MinSize,Max:MaxSize,Desired:DesiredCapacity,Current:length(Instances)}'
```

### Check EMR Virtual Clusters

```bash
# List all virtual clusters
aws emr-containers list-virtual-clusters --region us-east-1

# Get virtual cluster details
aws emr-containers describe-virtual-cluster \
  --id <CLUSTER_ID> \
  --region us-east-1

# Get job run status
aws emr-containers describe-job-run \
  --virtual-cluster-id <CLUSTER_ID> \
  --job-run-id <JOB_RUN_ID> \
  --region us-east-1
```

### Monitoring & Logs

```bash
# View cluster logs
aws logs tail /aws/eks/emr-eks-karpenter/cluster --follow

# View application logs
aws logs tail /aws/containerinsights/emr-eks-karpenter/application --follow

# View EMR job logs
aws logs tail /aws/emr/containers/emr-eks-karpenter --follow

# Access Grafana dashboards
kubectl port-forward -n monitoring svc/prometheus-grafana 3000:80

# Access Prometheus
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
```

### Submit Spark Job

```bash
# Get virtual cluster ID
VCLUSTER_ID=$(aws emr-containers list-virtual-clusters \
  --query 'virtualClusters[0].id' \
  --output text)

# Get job execution role
JOB_ROLE=$(aws iam get-role \
  --role-name data-team-a-job-execution \
  --query 'Role.Arn' \
  --output text)

# Submit job
aws emr-containers start-job-run \
  --virtual-cluster-id $VCLUSTER_ID \
  --name my-spark-job \
  --execution-role-arn $JOB_ROLE \
  --release-label emr-6.15.0-latest \
  --job-driver '{
    "sparkSubmitJobDriver": {
      "entryPoint": "s3://my-bucket/job.py",
      "sparkSubmitParameters": "--deploy-mode cluster --executor-memory 2G"
    }
  }' \
  --region us-east-1
```

## Stack Operations

### View Stack Status

```bash
# List all EMR on EKS stacks
aws cloudformation list-stacks \
  --query 'StackSummaries[?contains(StackName, `emr-eks-cf`)].{Name:StackName,Status:StackStatus}' \
  --region us-east-1

# Get stack details
aws cloudformation describe-stacks \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1 \
  --query 'Stacks[0]'

# Get stack outputs
aws cloudformation describe-stacks \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1 \
  --query 'Stacks[0].Outputs'
```

### Update Stack

```bash
# Update node count
aws cloudformation update-stack \
  --stack-name emr-eks-cf-cluster \
  --template-body file://3-eks-cluster-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --parameters \
    ParameterKey=NodeDesiredSize,UsePreviousValue=false,ParameterValue=5 \
  --region us-east-1
```

### Delete Stack

```bash
# Delete all stacks (in reverse order)
for stack in \
  emr-eks-cf-monitoring \
  emr-eks-cf-storage \
  emr-eks-cf-emr-clusters \
  emr-eks-cf-cluster \
  emr-eks-cf-iam \
  emr-eks-cf-network; do
  
  echo "Deleting $stack..."
  aws cloudformation delete-stack \
    --stack-name $stack \
    --region us-east-1
  
  aws cloudformation wait stack-delete-complete \
    --stack-name $stack \
    --region us-east-1
  
  echo "$stack deleted"
done
```

## Auto Scaling Policies

### View Current Policies

```bash
# List scaling policies
aws autoscaling describe-policies \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg \
  --region us-east-1

# Check scaling activities
aws autoscaling describe-scaling-activities \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg \
  --max-records 10 \
  --region us-east-1
```

### Modify Scaling Thresholds

Edit `3-eks-cluster-stack.yaml`:

```yaml
ScaleUpPolicy:
  Properties:
    TargetTrackingConfiguration:
      TargetValue: 75.0  # Change from 70.0

ScaleDownPolicy:
  Properties:
    TargetTrackingConfiguration:
      TargetValue: 25.0  # Change from 30.0
```

Then update the stack:

```bash
aws cloudformation update-stack \
  --stack-name emr-eks-cf-cluster \
  --template-body file://3-eks-cluster-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1
```

## Cost Optimization Tips

1. **Right-size instances** - Use `t3.xlarge` for development, `m5.xlarge` for production
2. **Adjust scaling** - Set `NodeMaxSize` to match your workload peak
3. **Limit retention** - Reduce CloudWatch log retention from 30 to 7 days
4. **Use spot instances** - EMR doesn't support spot, but use on-demand commitments
5. **Archive old data** - Use S3 Glacier for historical EMR outputs

## Troubleshooting Commands

### Debug Stack Creation Failures

```bash
# Get stack events
aws cloudformation describe-stack-events \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1 \
  --query 'StackEvents[?ResourceStatus==`CREATE_FAILED`]'

# Check Lambda function logs
aws logs tail /aws/lambda/CreateEMRVirtualClusterFunction --follow

# Get CloudFormation error messages
aws cloudformation describe-stacks \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1 \
  --query 'Stacks[0].StackStatusReason'
```

### Debug Kubectl Connection

```bash
# Check kubeconfig
kubectl config view

# Test API access
kubectl auth can-i list nodes

# Check API server connectivity
kubectl get --raw /api/v1/namespaces | head -20

# Debug pod connectivity
kubectl exec -it <POD_NAME> -- /bin/sh
```

### Debug Node Issues

```bash
# Check node status
kubectl describe node <NODE_NAME>

# View node events
kubectl get events --all-namespaces --field-selector involvedObject.kind=Node

# SSH into node (requires Session Manager)
aws ssm start-session --target i-xxxxxxxxx

# View system logs
sudo journalctl -u kubelet -f
sudo tail -f /var/log/docker
```

## Important Endpoints & Resources

| Resource | Location | Access |
|----------|----------|--------|
| EKS API | https://eks.{region}.amazonaws.com | AWS CLI / kubectl |
| Grafana | localhost:3000 (port-forward) | kubectl port-forward |
| Prometheus | localhost:9090 (port-forward) | kubectl port-forward |
| CloudWatch | AWS Console | Browser |
| S3 Workload Bucket | s3://emr-eks-karpenter-emr-{account}-{region} | AWS CLI / Spark |
| EMR Virtual Clusters | AWS Console → EMR Containers | Browser |

## Default Credentials

| Service | Username | Password | How to Retrieve |
|---------|----------|----------|-----------------|
| Grafana | admin | prom-operator | Default Helm values |
| CloudWatch | N/A | AWS credentials | IAM roles |
| S3 | N/A | IAM roles | IRSA annotations |

## Links & Documentation

- [CloudFormation User Guide](https://docs.aws.amazon.com/cloudformation/)
- [EKS User Guide](https://docs.aws.amazon.com/eks/)
- [EMR on EKS](https://docs.aws.amazon.com/emr/latest/EMR-on-EKS-DevelopmentGuide/)
- [Auto Scaling](https://docs.aws.amazon.com/autoscaling/)
- [Spark on Kubernetes](https://spark.apache.org/docs/latest/running-on-kubernetes.html)

---

**Version**: 1.0  
**Last Updated**: April 7, 2026  
**Kubernetes**: 1.34  
**EMR**: 6.15.0 (configurable)
