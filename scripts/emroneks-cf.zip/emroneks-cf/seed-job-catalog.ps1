$ErrorActionPreference = 'Stop'
$env:AWS_PAGER = ''

$region = 'us-east-1'

function Get-StackOutput([string]$stackName, [string]$key) {
    $q = "Stacks[0].Outputs[?OutputKey=='$key'].OutputValue | [0]"
    $val = aws cloudformation describe-stacks --stack-name $stackName --region $region --query $q --output text
    if (-not $val -or $val -eq 'None') { throw "Missing output $key from $stackName" }
    return $val.Trim()
}

$catalogTable = Get-StackOutput 'emr-eks-cf-orchestration' 'JobCatalogTableName'
$bucket       = Get-StackOutput 'emr-eks-cf-iam'          'WorkloadBucketName'
$vcid         = Get-StackOutput 'emr-eks-cf-emr'          'DataTeamAVirtualClusterId'
$execRole     = Get-StackOutput 'emr-eks-cf-irsa'         'DataTeamAJobExecutionRoleArn'

$releaseLabel   = 'emr-7.5.0-latest'
$entryPoint     = 'local:///usr/lib/spark/examples/jars/spark-examples.jar'
$logUriPrefix   = "s3://$bucket/orchestration-logs"

# Helper: build a DynamoDB item JSON string for a SparkPi-based job.
# Each job uses SparkPi as a stand-in; real workloads replace EntryPoint + SparkSubmitParameters.
function Build-Item {
    param(
        [string]$JobName,
        [string]$Domain,
        [string]$Stage,
        [string]$Description,
        [int]$Iters
    )
    $sparkParams = "--class org.apache.spark.examples.SparkPi " +
                   "--conf spark.executor.instances=1 " +
                   "--conf spark.executor.memory=1G " +
                   "--conf spark.driver.memory=1G " +
                   "--conf spark.executor.cores=1 " +
                   "--conf app.domain=$Domain " +
                   "--conf app.stage=$Stage"

    # Build DynamoDB JSON attribute map
    $item = [ordered]@{
        JobName              = @{ S = $JobName }
        VirtualClusterId     = @{ S = $vcid }
        ExecutionRoleArn     = @{ S = $execRole }
        ReleaseLabel         = @{ S = $releaseLabel }
        EntryPoint           = @{ S = $entryPoint }
        EntryPointArguments  = @{ L = @(@{ S = "$Iters" }) }
        SparkSubmitParameters = @{ S = $sparkParams }
        LogUriPrefix         = @{ S = $logUriPrefix }
        Description          = @{ S = $Description }
    }
    return $item | ConvertTo-Json -Depth 10
}

# 10-job sales + insurance catalog entries
$jobs = @(
    @{ Name='sales-ingest';                Domain='sales';     Stage='ingest';    Iters=40;  Desc='Sales domain: raw data ingestion from source systems' },
    @{ Name='insurance-ingest';            Domain='insurance'; Stage='ingest';    Iters=45;  Desc='Insurance domain: raw policy + claims ingestion' },
    @{ Name='customer-reference-build';    Domain='shared';    Stage='reference'; Iters=35;  Desc='Shared: build unified customer reference dataset' },
    @{ Name='sales-curation';              Domain='sales';     Stage='curation';  Iters=70;  Desc='Sales domain: curate and validate sales data' },
    @{ Name='insurance-claims-curation';   Domain='insurance'; Stage='curation';  Iters=75;  Desc='Insurance domain: curate and validate claims data' },
    @{ Name='customer-360-join';           Domain='shared';    Stage='join';      Iters=95;  Desc='Shared: join sales and insurance into customer-360 view' },
    @{ Name='risk-scoring';                Domain='insurance'; Stage='risk';      Iters=120; Desc='Insurance domain: compute risk scores per customer' },
    @{ Name='sales-forecast';              Domain='sales';     Stage='forecast';  Iters=115; Desc='Sales domain: predictive revenue forecasting' },
    @{ Name='fraud-detection';             Domain='insurance'; Stage='fraud';     Iters=130; Desc='Insurance domain: fraud pattern detection' },
    @{ Name='executive-kpi-publish';       Domain='shared';    Stage='publish';   Iters=150; Desc='Shared: generate and publish executive KPI dashboard' },

    # Simple 3-job test workflow entries (used by run-orchestration-test.ps1)
    @{ Name='ingest';    Domain='test'; Stage='ingest';    Iters=50;  Desc='Test: simple ingest stage' },
    @{ Name='transform'; Domain='test'; Stage='transform'; Iters=100; Desc='Test: simple transform stage' },
    @{ Name='quality';   Domain='test'; Stage='quality';   Iters=150; Desc='Test: simple quality check stage' }
)

Write-Host "Seeding job catalog table: $catalogTable"
Write-Host ""

foreach ($j in $jobs) {
    $itemJson = Build-Item -JobName $j.Name -Domain $j.Domain -Stage $j.Stage -Iters $j.Iters -Description $j.Desc
    $tmpItemPath = Join-Path $env:TEMP ("ddb-item-" + $j.Name + ".json")
    [System.IO.File]::WriteAllText($tmpItemPath, $itemJson, [System.Text.UTF8Encoding]::new($false))

    Write-Host "  PUT $($j.Name)..." -NoNewline

    aws dynamodb put-item `
        --region $region `
        --table-name $catalogTable `
        --item ("file://" + $tmpItemPath) | Out-Null

    if ($LASTEXITCODE -ne 0) {
        throw "Failed to insert job '$($j.Name)' into $catalogTable"
    }

    Remove-Item $tmpItemPath -ErrorAction SilentlyContinue

    Write-Host " OK"
}

Write-Host ""
Write-Host "Seeded $($jobs.Count) jobs into $catalogTable"
Write-Host ""
Write-Host "Verify with:"
Write-Host "  aws dynamodb scan --table-name $catalogTable --region $region --select COUNT"
