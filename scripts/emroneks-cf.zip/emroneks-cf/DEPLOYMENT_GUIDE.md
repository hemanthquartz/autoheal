# EMR on EKS - CloudFormation Deployment Guide

This directory contains modular CloudFormation templates to deploy a complete EMR on EKS infrastructure using traditional AWS Auto Scaling (replacing Karpenter).

## Stack Overview

| # | Stack Name | Template | Purpose | Dependencies |
|---|---|---|---|---|
| 1 | Network | `1-network-stack.yaml` | VPC, Subnets, Security Groups, Route Tables | None (foundation) |
| 2 | IAM | `2-iam-stack.yaml` | IAM Roles, Policies, S3 Bucket | None |
| 3 | EKS Cluster | `3-eks-cluster-stack.yaml` | EKS Cluster, Node Groups, Add-ons, Auto Scaling | Network, IAM |
| 4 | EMR Virtual Clusters | `4-emr-virtual-clusters-stack.yaml` | EMR Virtual Clusters, Namespaces, Spark Operator | EKS Cluster |
| 5 | Storage | `5-storage-stack.yaml` | EBS Storage Classes, S3 Configuration, Spark History Server | EKS Cluster, IAM |
| 6 | Monitoring | `6-monitoring-stack.yaml` | CloudWatch, Prometheus, Grafana, Fluent-Bit | EKS Cluster |

## Deployment Steps

### Prerequisites

1. **AWS CLI** configured with appropriate credentials
   ```bash
   aws configure
   ```

2. **kubectl** installed and configured
   ```bash
   aws eks update-kubeconfig --name emr-eks-karpenter --region us-east-1
   ```

3. **Helm** installed for package management
   ```bash
   curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
   ```

4. **Python 3.11+** with boto3 installed
   ```bash
   pip install boto3 pyyaml
   ```

### Step 1: Deploy Network Stack

```bash
aws cloudformation create-stack \
  --stack-name emr-eks-cf-network \
  --template-body file://1-network-stack.yaml \
  --region us-east-1 \
  --parameters \
    ParameterKey=VpcCIDR,ParameterValue=10.1.0.0/16 \
    ParameterKey=SecondaryVpcCIDR,ParameterValue=100.64.0.0/16

# Wait for stack creation to complete
aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-network \
  --region us-east-1
```

### Step 2: Deploy IAM Stack

```bash
aws cloudformation create-stack \
  --stack-name emr-eks-cf-iam \
  --template-body file://2-iam-stack.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1 \
  --parameters \
    ParameterKey=EKSClusterName,ParameterValue=emr-eks-karpenter

# Wait for stack creation
aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-iam \
  --region us-east-1
```

### Step 3: Deploy EKS Cluster Stack

**Note**: This stack requires the OIDC ID from the cluster, which is created during cluster creation. The stack includes a Lambda function to extract this automatically.

```bash
# Get Network Stack Outputs
NETWORK_STACK="emr-eks-cf-network"

VPC_ID=$(aws cloudformation describe-stacks \
  --stack-name $NETWORK_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`VpcId`].OutputValue' \
  --output text \
  --region us-east-1)

PRIVATE_SUBNETS=$(aws cloudformation describe-stacks \
  --stack-name $NETWORK_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`PrivateSubnets`].OutputValue' \
  --output text \
  --region us-east-1)

DATA_SUBNETS=$(aws cloudformation describe-stacks \
  --stack-name $NETWORK_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`DataSubnets`].OutputValue' \
  --output text \
  --region us-east-1)

CONTROL_PLANE_SG=$(aws cloudformation describe-stacks \
  --stack-name $NETWORK_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`EKSControlPlaneSecurityGroupId`].OutputValue' \
  --output text \
  --region us-east-1)

NODE_SG=$(aws cloudformation describe-stacks \
  --stack-name $NETWORK_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`EKSNodeSecurityGroupId`].OutputValue' \
  --output text \
  --region us-east-1)

# Get IAM Stack Outputs
IAM_STACK="emr-eks-cf-iam"

CLUSTER_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`EKSClusterRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

NODE_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`EKSNodeRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

NODE_INSTANCE_PROFILE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`EKSNodeInstanceProfileArn`].OutputValue' \
  --output text \
  --region us-east-1)

# Deploy EKS Stack
aws cloudformation create-stack \
  --stack-name emr-eks-cf-cluster \
  --template-body file://3-eks-cluster-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --parameters \
    ParameterKey=ClusterName,ParameterValue=emr-eks-karpenter \
    ParameterKey=KubernetesVersion,ParameterValue=1.34 \
    ParameterKey=ClusterRoleArn,ParameterValue=$CLUSTER_ROLE \
    ParameterKey=NodeRoleArn,ParameterValue=$NODE_ROLE \
    ParameterKey=NodeInstanceProfileArn,ParameterValue=$NODE_INSTANCE_PROFILE \
    ParameterKey=VpcId,ParameterValue=$VPC_ID \
    ParameterKey=PrivateSubnets,ParameterValue=\"${PRIVATE_SUBNETS// /,}\" \
    ParameterKey=DataSubnets,ParameterValue=\"${DATA_SUBNETS// /,}\" \
    ParameterKey=ControlPlaneSecurityGroupId,ParameterValue=$CONTROL_PLANE_SG \
    ParameterKey=NodeSecurityGroupId,ParameterValue=$NODE_SG \
    ParameterKey=NodeDesiredSize,ParameterValue=2 \
    ParameterKey=NodeMinSize,ParameterValue=1 \
    ParameterKey=NodeMaxSize,ParameterValue=3 \
    ParameterKey=NodeInstanceType,ParameterValue=m5.xlarge

# Wait for cluster to be created
aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1

echo "Cluster is being created. This may take 10-15 minutes..."
sleep 60
```

### Step 4: Configure kubectl

```bash
aws eks update-kubeconfig \
  --name emr-eks-karpenter \
  --region us-east-1

# Verify cluster connectivity
kubectl get nodes
```

### Step 5: Deploy EMR Virtual Clusters Stack

```bash
IAM_STACK="emr-eks-cf-iam"

TEAM_A_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`DataTeamAJobExecutionRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

TEAM_B_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`DataTeamBJobExecutionRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

aws cloudformation create-stack \
  --stack-name emr-eks-cf-emr-clusters \
  --template-body file://4-emr-virtual-clusters-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --parameters \
    ParameterKey=ClusterName,ParameterValue=emr-eks-karpenter \
    ParameterKey=DataTeamAJobExecutionRoleArn,ParameterValue=$TEAM_A_ROLE \
    ParameterKey=DataTeamBJobExecutionRoleArn,ParameterValue=$TEAM_B_ROLE

aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-emr-clusters \
  --region us-east-1

echo "EMR Virtual Clusters deployed successfully!"
```

### Step 6: Deploy Storage Stack

```bash
aws cloudformation create-stack \
  --stack-name emr-eks-cf-storage \
  --template-body file://5-storage-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --parameters \
    ParameterKey=ClusterName,ParameterValue=emr-eks-karpenter

aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-storage \
  --region us-east-1

echo "Storage stack deployed successfully!"
```

### Step 7: Deploy Monitoring Stack

```bash
IAM_STACK="emr-eks-cf-iam"

CLOUDWATCH_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`CloudWatchContainerInsightsRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

AMP_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`AMPRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

GRAFANA_ROLE=$(aws cloudformation describe-stacks \
  --stack-name $IAM_STACK \
  --query 'Stacks[0].Outputs[?OutputKey==`GrafanaRoleArn`].OutputValue' \
  --output text \
  --region us-east-1)

aws cloudformation create-stack \
  --stack-name emr-eks-cf-monitoring \
  --template-body file://6-monitoring-stack.yaml \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --parameters \
    ParameterKey=ClusterName,ParameterValue=emr-eks-karpenter \
    ParameterKey=CloudWatchContainerInsightsRoleArn,ParameterValue=$CLOUDWATCH_ROLE \
    ParameterKey=AMPRoleArn,ParameterValue=$AMP_ROLE \
    ParameterKey=GrafanaRoleArn,ParameterValue=$GRAFANA_ROLE

aws cloudformation wait stack-create-complete \
  --stack-name emr-eks-cf-monitoring \
  --region us-east-1

echo "Monitoring stack deployed successfully!"
```

## Automated Deployment Script

Use this PowerShell script to deploy all stacks automatically:

```powershell
# deploy-all-stacks.ps1

$AWS_REGION = "us-east-1"
$CLUSTER_NAME = "emr-eks-karpenter"

Write-Host "Starting EMR on EKS CloudFormation deployment..." -ForegroundColor Green

# Deploy Network Stack
Write-Host "`nDeploying Network Stack..." -ForegroundColor Cyan
aws cloudformation create-stack `
  --stack-name emr-eks-cf-network `
  --template-body file://1-network-stack.yaml `
  --region $AWS_REGION

aws cloudformation wait stack-create-complete `
  --stack-name emr-eks-cf-network `
  --region $AWS_REGION

Write-Host "Network Stack deployed!" -ForegroundColor Green

# Deploy IAM Stack
Write-Host "`nDeploying IAM Stack..." -ForegroundColor Cyan
aws cloudformation create-stack `
  --stack-name emr-eks-cf-iam `
  --template-body file://2-iam-stack.yaml `
  --capabilities CAPABILITY_NAMED_IAM `
  --region $AWS_REGION

aws cloudformation wait stack-create-complete `
  --stack-name emr-eks-cf-iam `
  --region $AWS_REGION

Write-Host "IAM Stack deployed!" -ForegroundColor Green

# Deploy EKS Cluster Stack
Write-Host "`nDeploying EKS Cluster Stack (this takes 10-15 minutes)..." -ForegroundColor Cyan
# ... retrieve stack outputs and deploy cluster stack ...

Write-Host "`nAll stacks deployed successfully!" -ForegroundColor Green
```

## Verify Deployment

```bash
# Check all CloudFormation stacks
aws cloudformation list-stacks \
  --query 'StackSummaries[?contains(StackName, `emr-eks-cf`)].{Name:StackName,Status:StackStatus}' \
  --region us-east-1

# Check cluster status
kubectl get nodes
kubectl get pods -A

# Check EMR virtual clusters
aws emr-containers list-virtual-clusters --region us-east-1

# Check monitoring
kubectl get pods -n monitoring
kubectl get svc -n monitoring
```

## Configuration Parameters

### Network Stack
- `VpcCIDR`: VPC CIDR block (default: 10.1.0.0/16)
- `SecondaryVpcCIDR`: Secondary CIDR for EKS workloads (default: 100.64.0.0/16)

### EKS Cluster Stack
- `KubernetesVersion`: Kubernetes version (default: 1.34)
- `NodeDesiredSize`: Desired number of nodes (default: 2)
- `NodeMinSize`: Minimum nodes for Auto Scaling (default: 1)
- `NodeMaxSize`: Maximum nodes for Auto Scaling (default: 3)
- `NodeInstanceType`: EC2 instance type (default: m5.xlarge)

## Key Differences from Terraform

1. **Auto Scaling**: Uses traditional AWS Auto Scaling Groups (ASG) with target tracking based on CPU utilization (70% scale-up, 30% scale-down) instead of Karpenter
2. **Modular Design**: Separated into 6 independent but interdependent stacks for better maintainability
3. **Custom Resources**: Uses Lambda functions for dynamic Kubernetes and EMR operations
4. **OIDC Provider Extraction**: Lambda automatically extracts and uses EKS OIDC provider for IRSA roles

## Troubleshooting

### Lambda Execution Errors

If Lambda functions fail during stack creation:

```bash
# Check CloudFormation events
aws cloudformation describe-stack-events \
  --stack-name emr-eks-cf-cluster \
  --region us-east-1 \
  --query 'StackEvents[?ResourceStatus==`CREATE_FAILED`]'

# Check Lambda logs
aws logs tail /aws/lambda/CreateEMRVirtualClusterFunction --follow --region us-east-1
```

### kubectl Access Issues

If kubectl commands fail after cluster creation:

```bash
# Re-configure kubeconfig
aws eks update-kubeconfig --name $CLUSTER_NAME --region $AWS_REGION

# Verify RBAC permissions
kubectl auth can-i list nodes
```

### Auto Scaling Not Working

Check ASG metrics and scaling policies:

```bash
aws autoscaling describe-auto-scaling-groups \
  --auto-scaling-group-names $(aws autoscaling describe-auto-scaling-groups \
    --query 'AutoScalingGroups[?contains(AutoScalingGroupName, `emr-eks-karpenter`)].AutoScalingGroupName' \
    --output text \
    --region us-east-1) \
  --region us-east-1

# Check scaling policies
aws autoscaling describe-policies \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg \
  --region us-east-1
```

## Cleanup

To delete all resources (in reverse order):

```bash
# Delete in reverse order of creation
for stack in emr-eks-cf-monitoring emr-eks-cf-storage emr-eks-cf-emr-clusters emr-eks-cf-cluster emr-eks-cf-iam emr-eks-cf-network; do
  echo "Deleting $stack..."
  aws cloudformation delete-stack --stack-name $stack --region us-east-1
  aws cloudformation wait stack-delete-complete --stack-name $stack --region us-east-1
  echo "$stack deleted!"
done

echo "All stacks cleaned up!"
```

## Support

For issues or questions, refer to:
- [AWS CloudFormation Documentation](https://docs.aws.amazon.com/cloudformation/)
- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [EMR on EKS Documentation](https://docs.aws.amazon.com/emr/latest/EMR-on-EKS-DevelopmentGuide/)
