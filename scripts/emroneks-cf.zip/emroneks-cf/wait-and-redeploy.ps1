# Wait for all stacks to finish deleting
Write-Host "Waiting for all stacks to finish deleting..."
$maxWait = 600  # 10 minutes
$elapsed = 0
$interval = 10

while ($elapsed -lt $maxWait) {
    $args = @('cloudformation', 'list-stacks', '--region', 'us-east-1', '--stack-status-filter', 'DELETE_IN_PROGRESS', '--query', "StackSummaries[?contains(StackName, 'emr-eks-cf')].StackName", '--output', 'text')
    $deleting = & aws @args 2>$null
    
    if ([string]::IsNullOrWhiteSpace($deleting)) {
        Write-Host "All stacks have been deleted."
        break
    }
    
    Write-Host "  Still deleting: $deleting (waited $elapsed/$maxWait seconds)"
    Start-Sleep -Seconds $interval
    $elapsed += $interval
}

if ($elapsed -ge $maxWait) {
    Write-Host "WARNING: Timeout waiting for stacks to delete after $maxWait seconds"
}

# Wait a bit more to be safe
Write-Host "Waiting 5 seconds before deployment..."
Start-Sleep -Seconds 5

# Now run fresh deployment
Write-Host "=== Starting Fresh Deployment ===" -ForegroundColor Cyan
.\deploy-all.ps1
