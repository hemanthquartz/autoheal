# EMR on EKS with CloudFormation and Auto Scaling

This directory contains a complete production-ready CloudFormation infrastructure-as-code implementation for deploying EMR (Elastic MapReduce) on Amazon EKS (Elastic Kubernetes Service) with traditional AWS Auto Scaling groups instead of Karpenter.

## Overview

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         AWS Account                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                   VPC (10.1.0.0/16)                      │  │
│  │                                                          │  │
│  │  ┌─────────────────────────────────────────────────┐   │  │
│  │  │        EKS Control Plane (Managed)              │   │  │
│  │  │   - API Endpoint (Public)                       │   │  │
│  │  │   - Kubernetes 1.34                             │   │  │
│  │  │   - Encryption (KMS)                            │   │  │
│  │  └─────────────────────────────────────────────────┘   │  │
│  │                                                          │  │
│  │  ┌─────────────────────────────────────────────────┐   │  │
│  │  │      Data Plane (100.64.0.0/16)                 │   │  │
│  │  │                                                  │   │  │
│  │  │  ┌───────────────────────────────────────────┐ │   │  │
│  │  │  │  Node Group: core-node-group (ASG)        │ │   │  │
│  │  │  │  - m5.xlarge instances                    │ │   │  │
│  │  │  │  - Desired: 2, Min: 1, Max: 3             │ │   │  │
│  │  │  │  - Target Tracking Scaling Policy         │ │   │  │
│  │  │  │  - CPU Target: 70% (scale up)             │ │   │  │
│  │  │  │  - CPU Target: 30% (scale down)           │ │   │  │
│  │  │  └───────────────────────────────────────────┘ │   │  │
│  │  │                                                  │   │  │
│  │  │  ┌───────────────────────────────────────────┐ │   │  │
│  │  │  │  Namespaces:                               │ │   │  │
│  │  │  │  - data-team-a (EMR Virtual Cluster)      │ │   │  │
│  │  │  │  - data-team-b (EMR Virtual Cluster)      │ │   │  │
│  │  │  │  - monitoring (Prometheus + Grafana)      │ │   │  │
│  │  │  │  - logging (Fluent-Bit)                   │ │   │  │
│  │  │  │  - spark-operator (Spark on K8s)          │ │   │  │
│  │  │  └───────────────────────────────────────────┘ │   │  │
│  │  │                                                  │   │  │
│  │  │  ┌───────────────────────────────────────────┐ │   │  │
│  │  │  │  Add-ons:                                  │ │   │  │
│  │  │  │  - VPC CNI (networking)                   │ │   │  │
│  │  │  │  - CoreDNS (service discovery)            │ │   │  │
│  │  │  │  - kube-proxy (network routing)           │ │   │  │
│  │  │  │  - EBS CSI Driver (persistent storage)    │ │   │  │
│  │  │  │  - CloudWatch Observability               │ │   │  │
│  │  │  │  - Metrics Server (HPA)                   │ │   │  │
│  │  │  └───────────────────────────────────────────┘ │   │  │
│  │  └─────────────────────────────────────────────────┘   │  │
│  │                                                          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │           Supporting Services                           │  │
│  │                                                          │  │
│  │  S3 Bucket (EMR Workloads)   ──────┐                   │  │
│  │  Amazon Managed Prometheus    ──────┤─ Observability   │  │
│  │  CloudWatch Logs              ──────┤                   │  │
│  │  Grafana Dashboard            ──────┘                   │  │
│  │                                                          │  │
│  │  IAM Roles (IRSA)             ──────┐                   │  │
│  │  KMS Encryption               ──────┤─ Security        │  │
│  │  Security Groups              ──────┘                   │  │
│  │                                                          │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Features

✅ **Kubernetes 1.34**
- Latest stable version for production
- KMS encryption for secrets
- Logging to CloudWatch

✅ **Auto Scaling (No Karpenter)**
- Traditional AWS Auto Scaling Groups (ASG)
- Target tracking scaling policies
- CPU-based scaling (70% up, 30% down)
- Min: 1, Max: 3 nodes (configurable)

✅ **EMR on EKS**
- 2 Virtual EMR clusters (data-team-a, data-team-b)
- Per-team job execution roles
- Spark Operator support
- Spark History Server

✅ **Storage**
- EBS GP3 encrypted storage class
- S3 bucket for EMR workloads
- 100GB persistent volume claims
- Lifecycle policies (30-day IA transition)

✅ **Observability**
- Amazon Managed Prometheus (AMP)
- Prometheus Operator + kube-prometheus-stack
- Grafana dashboards
- CloudWatch Container Insights
- Fluent-Bit log aggregation
- Custom Spark application dashboards

✅ **Security**
- IRSA (IAM Roles for Service Accounts)
- Pod security standards
- Network security groups
- Least privilege IAM policies
- KMS encryption at rest

✅ **High Availability**
- Multi-AZ deployment
- Managed service dependencies
- CloudWatch alarms ready
- Auto-healing nodes

## Files Structure

```
emroneks-cf/
├── 1-network-stack.yaml              # VPC, Subnets, Security Groups
├── 2-iam-stack.yaml                  # IAM Roles, Policies, S3 Bucket
├── 3-eks-cluster-stack.yaml          # EKS Cluster, Node Groups, Auto Scaling
├── 4-emr-virtual-clusters-stack.yaml # EMR Virtual Clusters, Spark Operator
├── 5-storage-stack.yaml              # EBS Storage, S3, Spark History Server
├── 6-monitoring-stack.yaml           # CloudWatch, Prometheus, Grafana, Fluent-Bit
├── DEPLOYMENT_GUIDE.md               # Step-by-step deployment instructions
└── README.md                          # This file
```

## Quick Start

### 1. Clone or Download Templates

All templates are in the `emroneks-cf/` directory.

### 2. Deploy Stacks (Fastest Method)

```bash
# Set variables
AWS_REGION="us-east-1"
CLUSTER_NAME="emr-eks-karpenter"

cd emroneks-cf

# Deploy all stacks in sequence
bash deploy-all.sh
```

### 3. Verify Deployment

```bash
# Configure kubectl
aws eks update-kubeconfig --name $CLUSTER_NAME --region $AWS_REGION

# Check nodes
kubectl get nodes

# Check EMR virtual clusters
aws emr-containers list-virtual-clusters --region $AWS_REGION

# Check monitoring
kubectl get pods -n monitoring
```

### 4. Submit a Spark Job

```bash
# Get data-team-a virtual cluster ID
VIRTUAL_CLUSTER_ID=$(aws emr-containers list-virtual-clusters \
  --query 'virtualClusters[?name==`data-team-a`].id' \
  --output text)

# Submit Spark job
aws emr-containers start-job-run \
  --virtual-cluster-id $VIRTUAL_CLUSTER_ID \
  --name test-job \
  --execution-role-arn $(aws iam get-role \
    --role-name data-team-a-job-execution \
    --query 'Role.Arn' \
    --output text) \
  --release-label emr-6.15.0-latest \
  --job-driver '{
    "sparkSubmitJobDriver": {
      "entryPoint": "s3://your-bucket/your-script.py",
      "sparkSubmitParameters": "--deploy-mode cluster --executor-memory 2G"
    }
  }' \
  --region $AWS_REGION
```

## Configuration

### Customize Node Settings

Edit `3-eks-cluster-stack.yaml`:

```yaml
Parameters:
  NodeDesiredSize:
    Default: 2        # Change desired count
  NodeMinSize:
    Default: 1        # Change minimum
  NodeMaxSize:
    Default: 3        # Change maximum
  NodeInstanceType:
    Default: m5.xlarge # Change instance type
```

### Customize Network

Edit `1-network-stack.yaml`:

```yaml
Parameters:
  VpcCIDR:
    Default: 10.1.0.0/16        # Change VPC CIDR
  SecondaryVpcCIDR:
    Default: 100.64.0.0/16      # Change secondary CIDR
```

### Enable Additional Features

In monitoring stack, uncomment to enable:
- FSx for Lustre (high-performance storage)
- Kubecost (cost monitoring)
- YuniKorn (advanced scheduling)

## Auto Scaling Details

### Scaling Policies

The infrastructure uses **Target Tracking Scaling** based on CPU utilization:

```
Scale Up:     When CPU > 70% → Add nodes
Scale Down:   When CPU < 30% → Remove nodes
Min Nodes:    1
Max Nodes:    3
Warmup:       300 seconds
```

### Monitoring Scaling

```bash
# Watch ASG scaling activity
watch -n 5 'aws autoscaling describe-auto-scaling-groups \
  --auto-scaling-group-names emr-eks-karpenter-core-node-asg \
  --query "AutoScalingGroups[0].[DesiredCapacity,Instances[].InstanceId]" \
  --output table'
```

## Cost Optimization

1. **On-Demand Instances**: Uses on-demand pricing for stability (no spot with EMR)
2. **Right-Sizing**: m5.xlarge is optimal for EMR workloads (4 vCPU, 16GB RAM)
3. **Auto Scaling**: Automatically scales down to 1 node during idle periods
4. **S3 Lifecycle**: Objects transition to Infrequent Access after 30 days
5. **CloudWatch**: 30-day log retention

### Estimated Monthly Cost (us-east-1)

| Resource | Qty | Cost |
|----------|-----|------|
| EC2 m5.xlarge (on-demand) | ~1.5 avg | ~$108 |
| EBS gp3 storage (100GB) | 1 | ~$8 |
| NAT Gateway | 1 | ~$32 |
| Public IP | 1 | ~$3 |
| S3 Storage (10GB avg) | 10GB | ~$0.25 |
| CloudWatch (logs + metrics) | Standard | ~$15 |
| Amazon Managed Prometheus | Minimal | ~$5 |
| **Total** | | **~$171** |

*Note: Prices are approximate and vary by usage patterns.*

## Monitoring and Observability

### CloudWatch Dashboards

Access cluster metrics:
```bash
aws cloudwatch get-dashboard --dashboard-name emr-eks-karpenter
```

### Grafana

Access Grafana dashboards:
```bash
# Port-forward Grafana
kubectl port-forward -n monitoring svc/prometheus-grafana 3000:80

# Open browser to http://localhost:3000
# Default credentials: admin/prom-operator
```

### Prometheus

Query metrics:
```bash
# Port-forward Prometheus
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090

# Open browser to http://localhost:9090
```

### CloudWatch Logs

View application logs:
```bash
aws logs tail \
  /aws/containerinsights/emr-eks-karpenter/application \
  --follow \
  --region us-east-1
```

## Troubleshooting

### Nodes Not Joining Cluster

```bash
# Check node CloudWatch logs
aws logs tail /aws/ec2/user-data --follow

# SSM into node
aws ssm start-session --target i-xxxxx --region us-east-1

# Check kubelet logs
sudo journalctl -u kubelet -f
```

### EMR Job Submission Fails

```bash
# Check job execution role
aws iam get-role --role-name data-team-a-job-execution

# Check S3 bucket access
aws s3 ls emr-eks-karpenter-emr-*

# Check EMR logs
aws logs tail /aws/emr/containers/emr-eks-karpenter --follow
```

### Scaling Not Working

```bash
# Check ASG policies
aws autoscaling describe-policies \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg

# Check recent scaling activity
aws autoscaling describe-scaling-activities \
  --auto-scaling-group-name emr-eks-karpenter-core-node-asg \
  --max-records 5
```

## Comparison: CloudFormation vs Terraform

| Aspect | CloudFormation | Terraform |
|--------|---|---|
| **Scaling** | ASG with target tracking | Karpenter (disabled due to ECR issues) |
| **State Management** | AWS-managed | Local tfstate file |
| **Modularity** | 6 separate stacks | Single/multiple modules |
| **Lambda Functions** | Native support | Via external provisioners |
| **Learning Curve** | AWS-centric | Cloud-agnostic |
| **Cost** | No additional cost | No additional cost |
| **Dependencies** | CloudFormation handles | Explicit depends_on |

## Key Differences from Original Terraform Setup

1. ✅ **No Karpenter**: Uses traditional Auto Scaling (more stable for EMR)
2. ✅ **Fully Modular**: 6 independent CloudFormation stacks
3. ✅ **Lambda Helper Functions**: Automates Kubernetes and EMR operations
4. ✅ **AWS Native**: Uses CloudFormation native features (no external tools needed)
5. ✅ **IAM IRSA Ready**: All roles pre-configured with OIDC trust relationships

## Support and Documentation

- [AWS CloudFormation User Guide](https://docs.aws.amazon.com/cloudformation/)
- [AWS EKS User Guide](https://docs.aws.amazon.com/eks/)
- [EMR on EKS Development Guide](https://docs.aws.amazon.com/emr/latest/EMR-on-EKS-DevelopmentGuide/)
- [Auto Scaling User Guide](https://docs.aws.amazon.com/autoscaling/)

## License

These templates are provided as-is for educational and commercial use.

## Contributing

To improve these templates, please test in your environment and report issues.

---

**Last Updated**: April 7, 2026  
**Template Version**: 1.0  
**Kubernetes Version**: 1.34  
**EMR Version**: 6.15.0 (configurable)
