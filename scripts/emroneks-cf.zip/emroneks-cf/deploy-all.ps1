﻿<#
.SYNOPSIS  Deploy all EMR-on-EKS CloudFormation stacks in dependency order.
.DESCRIPTION  Idempotent: creates stacks that don't exist, updates those that do.
#>
param(
    [string]$Region      = 'us-east-1',
    [string]$ClusterName = 'emr-eks-karpenter',
    [switch]$SkipMonitoring
)
Set-StrictMode -Off
$ErrorActionPreference = 'Continue'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

$NETWORK_STACK    = 'emr-eks-cf-network'
$IAM_STACK        = 'emr-eks-cf-iam'
$EKS_STACK        = 'emr-eks-cf-eks'
$IRSA_STACK       = 'emr-eks-cf-irsa'
$EMR_STACK        = 'emr-eks-cf-emr'
$MONITORING_STACK = 'emr-eks-cf-monitoring'

function Invoke-Aws {
    param([string[]]$CfArgs)
    $lines = @(& aws @CfArgs 2>&1 | ForEach-Object { "$_" })
    return [PSCustomObject]@{ Out = ($lines -join "`n"); Code = $LASTEXITCODE }
}

function Get-StackStatus {
    param([string]$Name)
    $r = Invoke-Aws @('cloudformation','describe-stacks','--stack-name',$Name,'--region',$Region,'--query','Stacks[0].StackStatus','--output','text')
    if ($r.Code -ne 0 -or $r.Out -match 'does not exist') { return $null }
    $s = $r.Out.Trim()
    if ($s -eq '' -or $s -eq 'None') { return $null }
    return $s
}

function Get-StackOutput {
    param([string]$StackName, [string]$Key)
    $query = "Stacks[0].Outputs[?OutputKey=='$Key'].OutputValue|[0]"
    $r = Invoke-Aws @('cloudformation','describe-stacks','--stack-name',$StackName,'--region',$Region,'--query',$query,'--output','text')
    if ($r.Code -ne 0) { throw "Failed to get '$Key' from '$StackName': $($r.Out)" }
    $val = $r.Out.Trim()
    if ($val -eq '' -or $val -eq 'None') { throw "Output '$Key' not found in stack '$StackName'" }
    return $val
}

function Wait-Stack {
    param([string]$Name, [string]$Op)
    Write-Host "  Waiting for $Name ($Op)..." -NoNewline
    $r = Invoke-Aws @('cloudformation','wait',"stack-$Op-complete",'--stack-name',$Name,'--region',$Region)
    if ($r.Code -ne 0) {
        $st = Get-StackStatus $Name
        throw "Stack '$Name' $Op wait failed (status=$st): $($r.Out)"
    }
    Write-Host " done."
}

function Remove-StackBlocking {
    param([string]$Name)
    Write-Host "  Deleting $Name ..."
    Invoke-Aws @('cloudformation','delete-stack','--stack-name',$Name,'--region',$Region) | Out-Null
    Wait-Stack $Name 'delete'
}

function New-ParamsFile {
    param([hashtable]$Params)
    if ($null -eq $Params -or $Params.Count -eq 0) { return $null }
    $file = Join-Path $env:TEMP ("cfparams-" + [guid]::NewGuid() + ".json")
    $arr = [System.Collections.Generic.List[object]]::new()
    foreach ($kv in $Params.GetEnumerator()) {
        $v = if ($kv.Value -is [array]) { $kv.Value -join ',' } else { [string]$kv.Value }
        $arr.Add([ordered]@{ ParameterKey = $kv.Key; ParameterValue = $v })
    }
    # Always emit an array
    $json = ConvertTo-Json -InputObject @($arr.ToArray()) -Depth 4
    [System.IO.File]::WriteAllText($file, $json, [System.Text.Encoding]::ASCII)
    return $file
}

function Deploy-Stack {
    param([string]$Name, [string]$Template, [hashtable]$Params = @{})
    $tmplPath = Join-Path $ScriptDir $Template
    $st = Get-StackStatus $Name

    # Auto-cleanup unrecoverable states
    $badStates = @('ROLLBACK_COMPLETE','ROLLBACK_FAILED','CREATE_FAILED','DELETE_FAILED','UPDATE_ROLLBACK_FAILED')
    if ($st -in $badStates) {
        Write-Host "[$Name] Removing failed stack (state=$st) ..."
        Remove-StackBlocking $Name
        $st = $null
    }

    $pf = New-ParamsFile $Params
    try {
        $op = if ($null -eq $st) { 'create-stack' } else { 'update-stack' }
        $cfArgs = @('cloudformation', $op,
                    '--stack-name',   $Name,
                    '--region',       $Region,
                    '--template-body',"file://$tmplPath",
                    '--capabilities', 'CAPABILITY_NAMED_IAM')
        if ($pf) { $cfArgs += @('--parameters', "file://$pf") }

        if ($null -eq $st) {
            Write-Host "[$Name] Creating from $Template ..."
        } else {
            Write-Host "[$Name] Updating (was: $st) ..."
        }

        $r = Invoke-Aws $cfArgs
        if ($r.Code -ne 0) {
            if ($r.Out -match 'No updates are to be performed') {
                Write-Host "  No changes for $Name."
                return
            }
            throw "[$Name] $op failed:`n$($r.Out)"
        }

        $waitOp = if ($null -eq $st) { 'create' } else { 'update' }
        Wait-Stack $Name $waitOp
    }
    finally {
        if ($pf) { Remove-Item $pf -ErrorAction SilentlyContinue }
    }

    $final = Get-StackStatus $Name
    Write-Host "  -> $Name : $final"
    if ($final -notmatch 'COMPLETE') { throw "$Name ended in state: $final" }
}

# ---- preflight ---------------------------------------------------------------
Write-Host "`n=== EMR on EKS - Full Stack Deployment ===" -ForegroundColor Cyan
Write-Host "Region  : $Region`nCluster : $ClusterName`n"
foreach ($cmd in @('aws','kubectl')) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "'$cmd' not found." }
}

# ---- 1: Network --------------------------------------------------------------
Deploy-Stack $NETWORK_STACK '1-network-stack.yaml'
$VpcId          = Get-StackOutput $NETWORK_STACK 'VpcId'
$PrivateSubnets = Get-StackOutput $NETWORK_STACK 'PrivateSubnets'
$DataSubnets    = Get-StackOutput $NETWORK_STACK 'DataSubnets'
$CPsgId         = Get-StackOutput $NETWORK_STACK 'EKSControlPlaneSecurityGroupId'
$NodeSGId       = Get-StackOutput $NETWORK_STACK 'EKSNodeSecurityGroupId'
Write-Host "  VPC=$VpcId`n  Private=$PrivateSubnets`n  Data=$DataSubnets"

# ---- 2: IAM Base -------------------------------------------------------------
Deploy-Stack $IAM_STACK '2-iam-base-stack.yaml' @{ ClusterName = $ClusterName }
$ClusterRoleArn    = Get-StackOutput $IAM_STACK 'ClusterRoleArn'
$NodeRoleArn       = Get-StackOutput $IAM_STACK 'NodeRoleArn'
$EncryptionKeyArn  = Get-StackOutput $IAM_STACK 'EncryptionKeyArn'
$WorkloadBucketArn = Get-StackOutput $IAM_STACK 'WorkloadBucketArn'

# ---- 3: EKS Cluster + OIDC + Namespaces --------------------------------------
Deploy-Stack $EKS_STACK '3-eks-cluster-stack.yaml' @{
    ClusterName                 = $ClusterName
    ClusterRoleArn              = $ClusterRoleArn
    NodeRoleArn                 = $NodeRoleArn
    EncryptionKeyArn            = $EncryptionKeyArn
    VpcId                       = $VpcId
    PrivateSubnets              = $PrivateSubnets
    DataSubnets                 = $DataSubnets
    ControlPlaneSecurityGroupId = $CPsgId
    NodeSecurityGroupId         = $NodeSGId
}
Write-Host "  Updating kubeconfig..."
& aws eks update-kubeconfig --region $Region --name $ClusterName 2>&1 | Out-Null
$OIDCProviderArn = Get-StackOutput $EKS_STACK 'OIDCProviderArn'
$OIDCHostname    = Get-StackOutput $EKS_STACK 'OIDCHostname'
Write-Host "  OIDC ARN  : $OIDCProviderArn"
Write-Host "  OIDC Host : $OIDCHostname"

# ---- 4: IRSA Roles + Add-ons -------------------------------------------------
Deploy-Stack $IRSA_STACK '4-irsa-addons-stack.yaml' @{
    ClusterName       = $ClusterName
    OIDCProviderArn   = $OIDCProviderArn
    OIDCHostname      = $OIDCHostname
    WorkloadBucketArn = $WorkloadBucketArn
}
$DataTeamARoleArn = Get-StackOutput $IRSA_STACK 'DataTeamAJobExecutionRoleArn'
$DataTeamBRoleArn = Get-StackOutput $IRSA_STACK 'DataTeamBJobExecutionRoleArn'

# ---- 5: EMR Virtual Clusters -------------------------------------------------
Deploy-Stack $EMR_STACK '5-emr-clusters-stack.yaml' @{
    ClusterName                  = $ClusterName
    DataTeamAJobExecutionRoleArn = $DataTeamARoleArn
    DataTeamBJobExecutionRoleArn = $DataTeamBRoleArn
}
$VCIdA = Get-StackOutput $EMR_STACK 'DataTeamAVirtualClusterId'
$VCIdB = Get-StackOutput $EMR_STACK 'DataTeamBVirtualClusterId'

# ---- 6: Monitoring -----------------------------------------------------------
if (-not $SkipMonitoring) {
    Deploy-Stack $MONITORING_STACK '6-monitoring-stack.yaml' @{ ClusterName = $ClusterName }
}

# ---- Summary -----------------------------------------------------------------
Write-Host "`n=== Deployment Complete ===" -ForegroundColor Green
Write-Host "Cluster         : $ClusterName"
Write-Host "OIDC Hostname   : $OIDCHostname"
Write-Host "Team A VC ID    : $VCIdA"
Write-Host "Team B VC ID    : $VCIdB"
Write-Host "Workload Bucket : $(Get-StackOutput $IAM_STACK 'WorkloadBucketName')"
Write-Host "`nSmoke test:" -ForegroundColor Cyan
Write-Host "  aws emr-containers start-job-run --virtual-cluster-id $VCIdA --execution-role-arn $DataTeamARoleArn ..."
