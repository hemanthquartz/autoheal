$ErrorActionPreference = 'Continue'
Set-Location "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf"

$stacks = @('emr-eks-cf-monitoring','emr-eks-cf-emr','emr-eks-cf-irsa','emr-eks-cf-eks','emr-eks-cf-iam','emr-eks-cf-network')
$region = 'us-east-1'

Write-Host "=== Current Stack States ===" -ForegroundColor Cyan
foreach($s in $stacks) {
    $status = aws cloudformation describe-stacks --stack-name $s --region $region --query 'Stacks[0].StackStatus' --output text 2>&1
    if($LASTEXITCODE -eq 0) {
        Write-Host "$s : $status"
    } else {
        Write-Host "$s : NOT_FOUND"
    }
}

Write-Host "`n=== Deleting remaining stacks ===" -ForegroundColor Cyan
foreach($s in $stacks) {
    $status = aws cloudformation describe-stacks --stack-name $s --region $region --query 'Stacks[0].StackStatus' --output text 2>&1
    if($LASTEXITCODE -eq 0) {
        Write-Host "Deleting $s..."
        aws cloudformation delete-stack --stack-name $s --region $region 2>&1 | Out-Null
        aws cloudformation wait stack-delete-complete --stack-name $s --region $region 2>&1
        Write-Host "  Deleted $s" -ForegroundColor Green
    }
}

Write-Host "`n=== Running full deployment ===" -ForegroundColor Cyan
& ".\deploy-all.ps1" 2>&1 | Tee-Object -FilePath ".\deploy-reset.log"

Write-Host "`n=== Final Stack Status ===" -ForegroundColor Cyan
aws cloudformation describe-stacks --region $region --query "Stacks[?starts_with(StackName,'emr-eks-cf-')].[StackName,StackStatus]" --output table

Write-Host "`n=== EMR Virtual Cluster IDs ===" -ForegroundColor Cyan
aws cloudformation describe-stacks --stack-name emr-eks-cf-emr --region $region --query "Stacks[0].Outputs[?OutputKey=='DataTeamAVirtualClusterId' || OutputKey=='DataTeamBVirtualClusterId'].[OutputKey,OutputValue]" --output table

Write-Host "`n=== Pod Status ===" -ForegroundColor Cyan
kubectl get pods -A --no-headers | Select-String -Pattern "Running" | Measure-Object | Select-Object -ExpandProperty Count | ForEach-Object { Write-Host "Total Running pods: $_" }
