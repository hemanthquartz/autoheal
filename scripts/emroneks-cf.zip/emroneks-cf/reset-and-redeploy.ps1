$ErrorActionPreference = 'Continue'
$PSNativeCommandUseErrorActionPreference = $false
Set-Location "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf"

$stacks = @(
  'emr-eks-cf-monitoring',
  'emr-eks-cf-emr',
  'emr-eks-cf-irsa',
  'emr-eks-cf-eks',
  'emr-eks-cf-iam',
  'emr-eks-cf-network'
)

foreach ($s in $stacks) {
  & aws cloudformation describe-stacks --stack-name $s --region us-east-1 --query 'Stacks[0].StackStatus' --output text 1>$null 2>$null
  if ($LASTEXITCODE -eq 0) {
    Write-Host "Deleting $s"
    & aws cloudformation delete-stack --stack-name $s --region us-east-1 | Out-Null
    & aws cloudformation wait stack-delete-complete --stack-name $s --region us-east-1
    Write-Host "Deleted $s"
  }
  else {
    Write-Host "Skip $s (not found)"
  }
}

Write-Host "Starting fresh deployment..."
.\deploy-all.ps1 2>&1 | Tee-Object -FilePath .\deploy-reset.log

Write-Host "Final statuses:"
aws cloudformation describe-stacks --region us-east-1 --query "Stacks[?starts_with(StackName, 'emr-eks-cf-')].[StackName,StackStatus]" --output table

Write-Host "EMR virtual cluster IDs:"
$outs = aws cloudformation describe-stacks --stack-name emr-eks-cf-emr --region us-east-1 --query "Stacks[0].Outputs[].[OutputKey,OutputValue]" --output text
$outs | Select-String "DataTeamAVirtualClusterId|DataTeamBVirtualClusterId"
