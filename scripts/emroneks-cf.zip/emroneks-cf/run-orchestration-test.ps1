$ErrorActionPreference = 'Stop'
$env:AWS_PAGER = ''

Set-Location "C:\Users\Keerthi\OneDrive\Documents\cft"
$region = 'us-east-1'

function Get-StackOutput([string]$stackName, [string]$key) {
    $q = "Stacks[0].Outputs[?OutputKey=='$key'].OutputValue | [0]"
    $val = aws cloudformation describe-stacks --stack-name $stackName --region $region --query $q --output text
    if (-not $val -or $val -eq 'None') { throw "Missing output $key from $stackName" }
    return $val.Trim()
}

$queueUrl = Get-StackOutput 'emr-eks-cf-orchestration' 'OrchestrationQueueUrl'
$stateMachineArn = Get-StackOutput 'emr-eks-cf-orchestration' 'StateMachineArn'
$tableName = Get-StackOutput 'emr-eks-cf-orchestration' 'JobStateTableName'

$workflowId = "wf-sample-" + (Get-Date -Format 'yyyyMMddHHmmss')

# Job config (code location, pod config, Spark params) lives in the DynamoDB job-catalog table.
# The SQS payload only carries the workflow structure: job names + dependencies.
$payload = [ordered]@{
    workflowId = $workflowId
    jobs = @(
        @{ name = 'ingest';    dependsOn = @() },
        @{ name = 'transform'; dependsOn = @('ingest') },
        @{ name = 'quality';   dependsOn = @('transform') }
    )
}

$body = $payload | ConvertTo-Json -Depth 10 -Compress
$payloadPath = "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\workflow-payload.json"
[System.IO.File]::WriteAllText($payloadPath, $body, [System.Text.Encoding]::ASCII)

$send = aws sqs send-message --region $region --queue-url $queueUrl --message-body "file://$payloadPath" --output json | ConvertFrom-Json
if ($LASTEXITCODE -ne 0) { throw 'Failed to send SQS message' }

$result = [pscustomobject]@{
    workflowId      = $workflowId
    messageId       = $send.MessageId
    queueUrl        = $queueUrl
    stateMachineArn = $stateMachineArn
    tableName       = $tableName
}

$result | ConvertTo-Json -Compress | Set-Content "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\last-workflow.json" -Encoding ASCII
$result | ConvertTo-Json -Depth 5
