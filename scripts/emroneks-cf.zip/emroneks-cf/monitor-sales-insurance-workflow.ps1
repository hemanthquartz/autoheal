$ErrorActionPreference = 'Stop'
$env:AWS_PAGER = ''

$metaPath = "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\last-workflow-sales-insurance.json"
if (-not (Test-Path $metaPath)) {
    throw "Missing $metaPath. Run run-sales-insurance-workflow.ps1 first."
}

$meta = Get-Content $metaPath | ConvertFrom-Json
$wf = $meta.workflowId
$sm = $meta.stateMachineArn
$tbl = $meta.tableName
$vcid = $meta.virtualClusterId
$region = 'us-east-1'

$exec = aws stepfunctions list-executions --state-machine-arn $sm --region $region --max-results 50 --query "executions[?contains(name, '$wf')]|[0]" --output json | ConvertFrom-Json
if ($null -eq $exec) {
    throw "No execution found for $wf"
}

$exprPath = "C:\Users\Keerthi\OneDrive\Documents\cft\emroneks-cf\ddb-expr-sales-insurance.json"
'{":w":{"S":"' + $wf + '"}}' | Set-Content -Path $exprPath -Encoding ASCII

for ($i=1; $i -le 40; $i++) {
    Write-Host "=== Poll $i ==="
    aws stepfunctions describe-execution --execution-arn $exec.executionArn --region $region --query "{status:status,startDate:startDate,stopDate:stopDate}" --output table
    aws dynamodb query --table-name $tbl --region $region --key-condition-expression "WorkflowId = :w" --expression-attribute-values file://$exprPath --query "Items[].{JobName:JobName.S,Status:Status.S,JobRunId:JobRunId.S}" --output table

    $status = aws stepfunctions describe-execution --execution-arn $exec.executionArn --region $region --query "status" --output text
    if ($status -in @('SUCCEEDED','FAILED','TIMED_OUT','ABORTED')) {
        Write-Host "Terminal workflow status: $status"
        break
    }
    Start-Sleep -Seconds 20
}

Write-Host "--- EMR Job Runs ---"
aws emr-containers list-job-runs --region $region --virtual-cluster-id $vcid --max-results 50 --query "jobRuns[?starts_with(name, '$wf')].[name,id,state,finishedAt]" --output table
