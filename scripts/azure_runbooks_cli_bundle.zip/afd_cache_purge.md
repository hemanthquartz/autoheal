RUNBOOK: Azure Front Door Cache Purge

INTENT
- Safely purge cached content from Azure Front Door.
- Ensure only intended routes and paths are purged.

SCOPE
- Trigger source: alert / operator request / deployment validation
- Target: Azure Front Door Standard/Premium endpoint
- Key identifiers: Resource Group, Profile Name, Endpoint Name, Content Paths

MANDATORY RULE
- Strict execution order is required.
- Do not purge all content unless explicitly approved.

PHASE 1: ENTRY GATE (Mandatory)
Objective:
- Confirm purge is required and scope is known.

Inputs:
- RESOURCE_GROUP
- PROFILE_NAME
- ENDPOINT_NAME
- CONTENT_PATHS (example: "/*" or "/images/*" "/css/*")

Decision:
- If endpoint or paths are missing:
  - STOP
  - Escalate for correct inputs
- If request is to purge everything (/*) without approval:
  - STOP
  - Escalate for approval
- Else:
  - Continue to Phase 2

PHASE 2: DISCOVERY (Mandatory)
Objective:
- Confirm the Front Door profile and endpoint exist.

CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify profile exists:
   az afd profile show \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output table

3) Verify endpoint exists:
   az afd endpoint show \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --endpoint-name <ENDPOINT_NAME> \
     --output table

Decision:
- If profile or endpoint lookup fails:
  - STOP
  - Escalate for manual investigation
- Else:
  - Continue to Phase 3

PHASE 3: REMEDIATION (Ordered)
Objective:
- Purge the intended cached paths.

CLI WORKFLOW
Run the purge command:
   az afd endpoint purge \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --endpoint-name <ENDPOINT_NAME> \
     --content-paths '/*'

Notes:
- Replace '/*' with specific paths whenever possible.
- For multiple paths, use:
  --content-paths '/images/*' '/css/*' '/js/*'

Failure handling:
- If purge command fails:
  - STOP
  - Capture CLI error output
  - Escalate
- If purge command succeeds:
  - Continue to Phase 4

PHASE 4: VALIDATION (Mandatory)
Objective:
- Confirm content is being served as expected after purge.

CLI WORKFLOW
1) Re-read endpoint details:
   az afd endpoint show \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --endpoint-name <ENDPOINT_NAME> \
     --query "{endpointName:name, hostName:hostName, enabledState:enabledState}" \
     --output json

2) Optional external validation from a client:
   curl -I https://<ENDPOINT_HOSTNAME>/<KNOWN_PATH>

Decision:
- If application/content behavior is corrected:
  - Close the incident/change task
- If behavior is still incorrect:
  - STOP
  - Escalate for origin/routing/cache-rule investigation

COMPLETION CRITERIA
Close only when all are true:
1) Correct Front Door endpoint was identified
2) Intended content paths were purged
3) Command completed successfully
4) Post-purge validation confirms expected content delivery
