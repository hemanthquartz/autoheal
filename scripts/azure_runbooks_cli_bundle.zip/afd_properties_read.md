RUNBOOK: Azure Front Door Read And Print Properties

INTENT
- Read and print Azure Front Door profile, endpoint, route, and origin properties.
- Support diagnostics and audit review without changing state.

SCOPE
- Trigger source: operator request / audit / troubleshooting
- Target: Azure Front Door Standard/Premium
- Key identifiers: Resource Group, Profile Name

MANDATORY RULE
- Read-only execution only.
- No update or purge action is allowed in this runbook.

PHASE 1: ENTRY GATE (Mandatory)
Objective:
- Confirm read-only property inspection is requested.

Inputs:
- RESOURCE_GROUP
- PROFILE_NAME

Decision:
- If required identifiers are missing:
  - STOP
- Else:
  - Continue to Phase 2

PHASE 2: DISCOVERY (Mandatory)
Objective:
- Verify the profile exists.

CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify profile:
   az afd profile show \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output table

Decision:
- If profile not found:
  - STOP
- Else:
  - Continue to Phase 3

PHASE 3: EXECUTION (Ordered)
Objective:
- Print properties of multiple Front Door services/components.

CLI WORKFLOW
1) Print profile properties:
   az afd profile show \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output json

2) Print endpoints:
   az afd endpoint list \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output table

3) Print routes:
   az afd route list \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output table

4) Print origin groups:
   az afd origin-group list \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --output table

5) Print origins:
   az afd origin list \
     --resource-group <RESOURCE_GROUP> \
     --profile-name <PROFILE_NAME> \
     --origin-group-name <ORIGIN_GROUP_NAME> \
     --output table

Optional focused queries:
- Endpoint details:
  az afd endpoint show --resource-group <RESOURCE_GROUP> --profile-name <PROFILE_NAME> --endpoint-name <ENDPOINT_NAME> --output json
- Route details:
  az afd route show --resource-group <RESOURCE_GROUP> --profile-name <PROFILE_NAME> --endpoint-name <ENDPOINT_NAME> --route-name <ROUTE_NAME> --output json

PHASE 4: VALIDATION (Mandatory)
Objective:
- Ensure the requested properties were printed successfully.

Decision:
- If outputs are returned for requested objects:
  - Close as completed
- If any object lookup fails:
  - STOP
  - Escalate with failing command and object name

COMPLETION CRITERIA
1) Profile verified
2) Requested properties printed
3) No changes made to production state
