Azure CLI Runbooks Bundle

These runbooks follow the same phased style as your examples, but each one now includes a CLI WORKFLOW section that can actually accomplish the task.

Prerequisites for all runbooks:
- Azure CLI installed
- az login completed
- Correct subscription selected: az account set --subscription <SUBSCRIPTION_ID_OR_NAME>
- Operator has required RBAC permissions

Important:
- Review placeholders before use.
- Some runbooks intentionally use validation and stop conditions to avoid unsafe automation.
- Commands are written to be copy/paste friendly.
