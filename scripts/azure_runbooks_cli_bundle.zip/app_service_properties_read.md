RUNBOOK: Azure App Service Read And Print Properties

INTENT
- Read and print properties of an Azure App Service and its configuration.
- Support troubleshooting and audit use cases.

SCOPE
- Trigger source: operator request / incident / audit
- Target: Azure Web App
- Key identifiers: Resource Group, App Name

MANDATORY RULE
- Read-only execution only.

PHASE 1: ENTRY GATE (Mandatory)
Objective:
- Confirm exact App Service target.

Inputs:
- RESOURCE_GROUP
- APP_NAME

Decision:
- If inputs missing:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify app exists:
   az webapp show \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output table

PHASE 3: EXECUTION (Ordered)
Objective:
- Print core and related properties.

CLI WORKFLOW
1) Print app details:
   az webapp show \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output json

2) Print app configuration:
   az webapp config show \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output json

3) Print app settings:
   az webapp config appsettings list \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output table

4) Print connection strings:
   az webapp config connection-string list \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output table

5) Print deployment slots:
   az webapp deployment slot list \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --output table

PHASE 4: VALIDATION (Mandatory)
Decision:
- If outputs returned successfully:
  - Close as completed
- Else:
  - STOP
  - Escalate with CLI error

COMPLETION CRITERIA
1) App identified correctly
2) Requested properties printed
3) No state change performed
