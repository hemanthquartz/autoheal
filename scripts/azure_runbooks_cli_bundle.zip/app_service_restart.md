RUNBOOK: Azure App Service Restart

INTENT
- Safely restart an Azure App Service when remediation is required.
- Avoid unnecessary restart if service is already healthy.

SCOPE
- Trigger source: alert / operator request
- Target: Azure Web App
- Key identifiers: Resource Group, App Name

MANDATORY RULE
- Restart only after health issue is confirmed.

PHASE 1: ENTRY GATE (Mandatory)
Objective:
- Decide if restart is allowed.

Inputs:
- RESOURCE_GROUP
- APP_NAME
- INCIDENT_REFERENCE

Decision:
- If no incident/change reference exists:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify app:
   az webapp show --resource-group <RESOURCE_GROUP> --name <APP_NAME> --output table

3) Optional pre-check:
   az webapp state show --resource-group <RESOURCE_GROUP> --name <APP_NAME>

PHASE 3: REMEDIATION (Ordered)
Objective:
- Restart the web app.

CLI WORKFLOW
1) Restart app:
   az webapp restart \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME>

2) Wait briefly and re-read state:
   az webapp show \
     --resource-group <RESOURCE_GROUP> \
     --name <APP_NAME> \
     --query "{name:name, state:state, defaultHostName:defaultHostName}" \
     --output json

Failure handling:
- If restart command fails:
  - STOP
  - Escalate
- Else continue

PHASE 4: VALIDATION (Mandatory)
Objective:
- Confirm app recovered.

CLI WORKFLOW
1) Read state again:
   az webapp show --resource-group <RESOURCE_GROUP> --name <APP_NAME> --query state --output tsv

2) Optional endpoint validation:
   curl -I https://<DEFAULT_HOSTNAME>

Decision:
- If state is Running and endpoint is healthy:
  - Close incident
- Else:
  - STOP
  - Escalate for deeper app diagnostics

COMPLETION CRITERIA
1) Correct app restarted
2) Restart command succeeded
3) Running state confirmed
4) Post-restart health verified
