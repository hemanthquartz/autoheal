RUNBOOK: Azure Key Vault Read And Print Properties

INTENT
- Read and print Key Vault properties and configuration.

SCOPE
- Trigger source: operator request / audit / troubleshooting
- Target: Azure Key Vault
- Key identifiers: Resource Group, Vault Name

MANDATORY RULE
- Read-only execution only.

PHASE 1: ENTRY GATE (Mandatory)
Inputs:
- RESOURCE_GROUP
- VAULT_NAME

Decision:
- If inputs missing:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify vault exists:
   az keyvault show \
     --resource-group <RESOURCE_GROUP> \
     --name <VAULT_NAME> \
     --output table

PHASE 3: EXECUTION (Ordered)
CLI WORKFLOW
1) Print vault properties:
   az keyvault show \
     --resource-group <RESOURCE_GROUP> \
     --name <VAULT_NAME> \
     --output json

2) Print certificate list:
   az keyvault certificate list \
     --vault-name <VAULT_NAME> \
     --output table

3) Print key list:
   az keyvault key list \
     --vault-name <VAULT_NAME> \
     --output table

4) Print secret list metadata:
   az keyvault secret list \
     --vault-name <VAULT_NAME> \
     --output table

PHASE 4: VALIDATION (Mandatory)
Decision:
- If outputs returned successfully:
  - Close as completed
- Else:
  - STOP
  - Escalate

COMPLETION CRITERIA
1) Vault identified
2) Requested properties printed
3) No change performed
