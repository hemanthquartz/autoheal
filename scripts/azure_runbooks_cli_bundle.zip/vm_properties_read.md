RUNBOOK: Azure Virtual Machine Read And Print Properties

INTENT
- Read and print VM properties for diagnostics and audit.

SCOPE
- Trigger source: operator request / audit / incident
- Target: Azure VM
- Key identifiers: Resource Group, VM Name

MANDATORY RULE
- Read-only execution only.

PHASE 1: ENTRY GATE (Mandatory)
Inputs:
- RESOURCE_GROUP
- VM_NAME

Decision:
- If missing inputs:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify VM exists:
   az vm show \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --output table

PHASE 3: EXECUTION (Ordered)
Objective:
- Print VM properties and related state.

CLI WORKFLOW
1) Print VM properties:
   az vm show \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --output json

2) Print instance view / power state:
   az vm get-instance-view \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --output json

3) Print NIC details used by the VM:
   az vm nic list \
     --resource-group <RESOURCE_GROUP> \
     --vm-name <VM_NAME> \
     --output table

4) Print disk attachments:
   az vm show \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --query "storageProfile" \
     --output json

PHASE 4: VALIDATION (Mandatory)
Decision:
- If requested outputs printed successfully:
  - Close as completed
- Else:
  - STOP
  - Escalate

COMPLETION CRITERIA
1) VM identified
2) Properties printed
3) No mutation performed
