RUNBOOK: Azure Cosmos DB Read And Print Properties

INTENT
- Read and print Cosmos DB account properties for diagnostics and audit.

SCOPE
- Trigger source: operator request / audit / troubleshooting
- Target: Azure Cosmos DB account
- Key identifiers: Resource Group, Account Name

MANDATORY RULE
- Read-only execution only.

PHASE 1: ENTRY GATE (Mandatory)
Inputs:
- RESOURCE_GROUP
- COSMOS_ACCOUNT_NAME

Decision:
- If inputs missing:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify Cosmos account exists:
   az cosmosdb show \
     --resource-group <RESOURCE_GROUP> \
     --name <COSMOS_ACCOUNT_NAME> \
     --output table

PHASE 3: EXECUTION (Ordered)
CLI WORKFLOW
1) Print account properties:
   az cosmosdb show \
     --resource-group <RESOURCE_GROUP> \
     --name <COSMOS_ACCOUNT_NAME> \
     --output json

2) Print locations:
   az cosmosdb show \
     --resource-group <RESOURCE_GROUP> \
     --name <COSMOS_ACCOUNT_NAME> \
     --query "locations" \
     --output json

3) Print keys metadata access command reference:
   az cosmosdb keys list \
     --resource-group <RESOURCE_GROUP> \
     --name <COSMOS_ACCOUNT_NAME> \
     --type keys \
     --output json

PHASE 4: VALIDATION (Mandatory)
Decision:
- If requested properties are printed:
  - Close as completed
- Else:
  - STOP
  - Escalate

COMPLETION CRITERIA
1) Account identified
2) Properties printed
3) No unsupported state change made
