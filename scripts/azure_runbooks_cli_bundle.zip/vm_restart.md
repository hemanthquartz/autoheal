RUNBOOK: Azure Virtual Machine Restart

INTENT
- Safely restart an Azure VM when remediation is required.

SCOPE
- Trigger source: alert / operator request
- Target: Azure VM
- Key identifiers: Resource Group, VM Name

MANDATORY RULE
- Restart only when the incident has been validated.

PHASE 1: ENTRY GATE (Mandatory)
Inputs:
- RESOURCE_GROUP
- VM_NAME
- INCIDENT_REFERENCE

Decision:
- If incident is not validated:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Read current power state:
   az vm get-instance-view \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --query "instanceView.statuses[?starts_with(code, 'PowerState/')].displayStatus" \
     --output tsv

PHASE 3: REMEDIATION (Ordered)
Objective:
- Restart the VM.

CLI WORKFLOW
1) Restart the VM:
   az vm restart \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME>

2) Re-read instance view:
   az vm get-instance-view \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --output json

Failure handling:
- If restart fails:
  - STOP
  - Escalate
- Else continue

PHASE 4: VALIDATION (Mandatory)
Objective:
- Confirm the VM returns to a running state.

CLI WORKFLOW
1) Validate power state:
   az vm get-instance-view \
     --resource-group <RESOURCE_GROUP> \
     --name <VM_NAME> \
     --query "instanceView.statuses[?starts_with(code, 'PowerState/')].displayStatus" \
     --output tsv

Decision:
- If output is VM running:
  - Close incident
- Else:
  - STOP
  - Escalate

COMPLETION CRITERIA
1) Correct VM restarted
2) Restart succeeded
3) Running state confirmed
