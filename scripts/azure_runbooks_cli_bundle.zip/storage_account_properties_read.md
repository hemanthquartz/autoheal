RUNBOOK: Azure Storage Account Read And Print Properties

INTENT
- Read and print Storage Account properties for diagnostics and audit.

SCOPE
- Trigger source: operator request / audit
- Target: Azure Storage Account
- Key identifiers: Resource Group, Storage Account Name

MANDATORY RULE
- Read-only execution only.

PHASE 1: ENTRY GATE (Mandatory)
Inputs:
- RESOURCE_GROUP
- STORAGE_ACCOUNT_NAME

Decision:
- If inputs missing:
  - STOP
- Else continue

PHASE 2: DISCOVERY (Mandatory)
CLI WORKFLOW
1) Set subscription:
   az account set --subscription <SUBSCRIPTION_ID_OR_NAME>

2) Verify storage account:
   az storage account show \
     --resource-group <RESOURCE_GROUP> \
     --name <STORAGE_ACCOUNT_NAME> \
     --output table

PHASE 3: EXECUTION (Ordered)
CLI WORKFLOW
1) Print storage account properties:
   az storage account show \
     --resource-group <RESOURCE_GROUP> \
     --name <STORAGE_ACCOUNT_NAME> \
     --output json

2) Print network rules:
   az storage account network-rule list \
     --resource-group <RESOURCE_GROUP> \
     --account-name <STORAGE_ACCOUNT_NAME> \
     --output json

3) Print blob service properties:
   az storage account blob-service-properties show \
     --account-name <STORAGE_ACCOUNT_NAME> \
     --resource-group <RESOURCE_GROUP> \
     --output json

PHASE 4: VALIDATION (Mandatory)
Decision:
- If outputs returned:
  - Close as completed
- Else:
  - STOP
  - Escalate

COMPLETION CRITERIA
1) Storage account identified
2) Requested properties printed
3) No change performed
